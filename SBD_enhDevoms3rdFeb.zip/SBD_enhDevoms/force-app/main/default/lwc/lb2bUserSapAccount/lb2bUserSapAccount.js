import { LightningElement, api, track, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import UserId from '@salesforce/user/Id';
import LB2BApplyMyAssignments from '@salesforce/label/c.LB2BApplyMyAssignments';
import LB2BNewAssignment from '@salesforce/label/c.LB2BNewAssignment';
import LB2BApplyAllAccounts from '@salesforce/label/c.LB2BApplyAllAccounts';
import LB2BApplyAllAccountsMessage from '@salesforce/label/c.LB2BApplyAllAccountsMessage';
import LB2BCancel from '@salesforce/label/c.LB2BCancel';
import LB2BConfirm from '@salesforce/label/c.LB2BConfirm';
import LB2BSoldToCustomer from '@salesforce/label/c.LB2BSoldToCustomer';
import LB2BShipToCustomer from '@salesforce/label/c.LB2BShipToCustomer';
import LB2BSelectSoldToShipTo from '@salesforce/label/c.LB2BSelectSoldToShipTo';
import LB2BDuplicateSoldToShipTo from '@salesforce/label/c.LB2BDuplicateSoldToShipTo';
import LB2BClose from '@salesforce/label/c.LB2BClose';
import LB2BAddMultipleAssignments from '@salesforce/label/c.LB2BAddMultipleAssignments';
import getAccounts from '@salesforce/apex/LB2BSapAccountTableController.getAccounts';
import { createRecord } from 'lightning/uiRecordApi';

export default class Lb2bUserSapAccount extends LightningElement {

    @api recordId;
    name;
    soldToAccount;
    shipToAccount;
    edit;
    isEditUser = false;
    isNewUser = false;
    isLoading = false;
    isMultipleAssignments = false;
    customClass = 'enabled'
    eventDetail;
    @api userdetailresult;

    label = {
        LB2BApplyMyAssignments,
        LB2BNewAssignment,
        LB2BApplyAllAccounts, 
        LB2BApplyAllAccountsMessage,
        LB2BConfirm,
        LB2BCancel,
        LB2BClose,
        LB2BAddMultipleAssignments,
        LB2BSoldToCustomer,
        LB2BShipToCustomer
    }

    @api
    get isCreateEdit() {
        return this.createEdit;
    }

    set isCreateEdit(value) {
        console.log("value", JSON.stringify(value))
        this.createEdit = value.createEditModal;
       // this.recordId = value.record != undefined ? value.record.Id : '';
        this.name = value.record != undefined ? value.record.User__c : '';
        // this.soldToAccount = value.record != undefined ? value.record.Sold_To_SAP_Account__c : '';
        // this.shipToAccount = value.record != undefined ? value.record.Ship_To_SAP_Account__c : '';
        this.isEditUser = value.record != undefined ? value.record.edit : '';
        this.isNewUser = value.record != undefined ? value.record.newUser : '';
        // this.isNewUser = true ;

        console.log('new user >>>',this.newUser);
        console.log('this.soldToAccount >>>',this.soldToAccount);
        console.log('edit user >>>',this.name);
    }

    hanldeMultipleShipTo(event){
        event.detail.forEach(shipTo => {
           this.shipToAccount = shipTo.id;
           this.updateNewAssignment();
            })
    }

    updateNewAssignment(){
        this.isLoading = true;
        console.log('userdetailresult >>>',JSON.parse(JSON.stringify(this.userdetailresult)));
        console.log('this.soldToAccount: ', this.soldToAccount, ' this.shipToAccount: ', this.shipToAccount);
        if ( (this.soldToAccount != null || this.soldToAccount != undefined)  && (this.shipToAccount != null || this.shipToAccount != undefined)) {
           let sapAccountInfo = JSON.parse(JSON.stringify(this.userdetailresult));
           let callCreateRecord = false; 
           sapAccountInfo.length == 0 ? callCreateRecord = true : callCreateRecord = false;
            for (let i = 0; i < sapAccountInfo.length; i++){
                if(this.soldToAccount == sapAccountInfo[i].Sold_To_SAP_Account__c
                    && this.shipToAccount == sapAccountInfo[i].Ship_To_SAP_Account__c
                    ){
                        this.isLoading = false;
                        this.dispatchEvent(
                            new ShowToastEvent({
                                message: LB2BDuplicateSoldToShipTo,
                                variant: 'error',
                            }),
                        );
                        callCreateRecord = false;
                        break;
                    }
                else {
                    callCreateRecord = true;
                }
            }

            if(callCreateRecord){
                alert('inside if')
                    const recordInput = {
                        "apiName": "User_Erp_Account__c",
                        "fields": {
                          "User__c" : this.name,
                          "Sold_To_SAP_Account__c": this.soldToAccount,
                          "Ship_To_SAP_Account__c":this.shipToAccount
                      }
                    }

    
                console.log('recordInput', recordInput, ' this.name: ', this.name);
                createRecord(recordInput)
                    .then((result) => {
                        console.log('result of createRecord: ', result);
                            const closeEvent = new CustomEvent("closemodalvalue", {               
                                detail: this.name               
                            });               
                        this.dispatchEvent(closeEvent); 
                        this.isLoading = false;
                        this.dispatchEvent(
                                    new ShowToastEvent({
                                        title: 'Success',
                                        message: 'Record created',
                                        variant: 'success',
                                    }),
                                );
                    this.shipToAccount = null;
                    this.soldToAccount = null;
                    
                    // let acctSelectorsold = this.template.querySelector('c-lb2b-user-management-account-selector');
                    // if (acctSelectorsold) {
                    //     acctSelectorsold.callSetValue(null);
                    // }

                    // let acctSelectorship = this.template.querySelector('c-lb2b-user-management-account-selector');
                    // if (acctSelectorship) {
                    //     acctSelectorship.callSetValue(null);
                    // }

                    })
                    .catch((error) => {
                        console.log('error', error);
                    });
                }
        } else {
            this.isLoading = false;
            this.dispatchEvent(
                new ShowToastEvent({
                    message: LB2BSelectSoldToShipTo,
                    variant: 'error',
                }),
            );
        }
        
    }

    validateInput(){
        this.customClass = [this.shipToAccount,this.soldToAccount].some(value => !value) === true ? 'disabled':'enabled';
    }

    handleSoldToAccountSelected(evt) {
        this.eventDetail = evt.detail.split('|')
        console.log("event detail", this.eventDetail)
        if(this.eventDetail[0] == 'SoldTo'){
            this.soldToAccount = this.eventDetail[1];
        }
        else{
            this.shipToAccount = this.eventDetail[1];
        }
        this.validateInput();
    //To get the shipto account for multiple ship to pop up
        getAccounts({ userId: UserId, sapNumber: this.eventDetail[2] })
        .then((result) => { 
            console.log("ship to account",result);
            if (!result.hasError) {
                this.sapAccounts = result.sapAccounts;
            }
        })
        .catch((error) => {
            console.error(error);
        });
       
    }
    
}