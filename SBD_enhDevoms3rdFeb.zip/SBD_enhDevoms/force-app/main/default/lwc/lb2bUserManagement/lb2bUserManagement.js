import { LightningElement, wire, api, track } from 'lwc';
import getUserDetails from '@salesforce/apex/LB2BUserManagement.getUserDetails';
import resetPassword from '@salesforce/apex/LB2BUserManagement.resetPassword';
import deactivateUser from '@salesforce/apex/LB2BUserManagement.deactivateUser';
import editUser from '@salesforce/apex/LB2BUserManagement.editUser';
import addUser from '@salesforce/apex/LB2BUserManagement.addUser';
import newUser from '@salesforce/apex/LB2BUserManagement.newUser';
import getUserSapAccInfo from '@salesforce/apex/LB2BUserInfo.getUserSapAccInfo';
import { deleteRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import Id from '@salesforce/user/Id';
import userAccountId from '@salesforce/schema/User.AccountId';
import FirstName from '@salesforce/schema/User.FirstName';
import LastName from '@salesforce/schema/User.LastName';
import Email from '@salesforce/schema/User.Email';
import Username from '@salesforce/schema/User.Username';
import Title from '@salesforce/schema/User.Title';
import IsActive  from '@salesforce/schema/User.IsActive';
import Alias from '@salesforce/schema/User.Alias';
import CommunityNickname from '@salesforce/schema/User.CommunityNickname';
import ProfileId  from '@salesforce/schema/User.ProfileId';
import LanguageLocaleKey  from '@salesforce/schema/User.LanguageLocaleKey';
import TimeZoneSidKey  from '@salesforce/schema/User.TimeZoneSidKey';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import { getRecord } from 'lightning/uiRecordApi';
import LB2BShip_To from '@salesforce/label/c.LB2BShip_To';
import LB2BAccount from '@salesforce/label/c.LB2BAccount';
import LB2BAddMember from '@salesforce/label/c.LB2BAddMember';
import LB2BBasicInformation from '@salesforce/label/c.LB2BBasicInformation';
import LB2BContactInformation from '@salesforce/label/c.LB2BContactInformation';
import LB2BLangLocaleSettings from '@salesforce/label/c.LB2BLangLocaleSettings';
import LB2BAccountsAssignments from '@salesforce/label/c.LB2BAccountsAssignments';
import LB2BSave from '@salesforce/label/c.LB2BSave';
import LB2BCancel from '@salesforce/label/c.LB2BCancel';
import LB2BResetPassword from '@salesforce/label/c.LB2BResetPassword';
import LB2BResetPasswordMessage from '@salesforce/label/c.LB2BResetPasswordMessage';
import LB2BDeactivate from '@salesforce/label/c.LB2BDeactivate';
import LB2BEdit from '@salesforce/label/c.LB2BEdit';
import LB2BName from '@salesforce/label/c.LB2BName';
import LB2BEmailId from '@salesforce/label/c.LB2BEmailId';
import LB2BTitle from '@salesforce/label/c.LB2BTitle';
import LB2BActive from '@salesforce/label/c.LB2BActive';
import LB2BUserName from '@salesforce/label/c.LB2BUserName';
import LB2BRemove from '@salesforce/label/c.LB2BRemove';
import LB2BSoldToNumber from '@salesforce/label/c.LB2BSoldToNumber';
import LB2BSoldToAddress from '@salesforce/label/c.LB2BSoldToAddress';
import LB2BShipToNumber from '@salesforce/label/c.LB2BShipToNumber';
import LB2BShipToAddress from '@salesforce/label/c.LB2BShipToAddress';
import LB2BEditAssignments from '@salesforce/label/c.LB2BEditAssignments';
import LB2BBuyer from '@salesforce/label/c.LB2BBuyer';
import LB2BStoreAdmin from '@salesforce/label/c.LB2BStoreAdmin';
import LB2BRequestorViewOnly from '@salesforce/label/c.LB2BRequestorViewOnly';
import LB2BUpdateUserMessage from '@salesforce/label/c.LB2BUpdateUserMessage';
import LB2BCreateUserMessage from '@salesforce/label/c.LB2BCreateUserMessage';
import LB2BEditMember from '@salesforce/label/c.LB2BEditMember';
//code added 
import LB2BEditUser from '@salesforce/label/c.LB2BEditUser';
import LB2BNewUser from '@salesforce/label/c.LB2BNewUser';
import LB2BDeactivateUser from '@salesforce/label/c.LB2BDeactivateUser';
import LB2BActivateUser from '@salesforce/label/c.LB2BActivateUser';
import ownerUserErpAccounts from '@salesforce/apex/LB2BUserManagement.ownerUserErpAccounts';
import LB2BApplyAllAccountsMessage from '@salesforce/label/c.LB2BApplyAllAccountsMessage';
import LB2BApplyAllAccounts from '@salesforce/label/c.LB2BApplyAllAccounts';
import LB2BConfirm from '@salesforce/label/c.LB2BConfirm';
import LB2BApplyAllAssignments from '@salesforce/label/c.LB2BApplyAllAssignments';
import LB2BNext from '@salesforce/label/c.LB2BNext';
import LB2bPrevious from '@salesforce/label/c.LB2bPrevious';
import LB2BFullName from '@salesforce/label/c.LB2BFullName';
import LB2BNoAssignment from '@salesforce/label/c.LB2BNoAssignment';



const actions = [
    { label: LB2BDeactivate, name: 'deactivate' },
    { label: LB2BEdit, name: 'edit' }, 
    { label: LB2BResetPassword, name: 'reset_Password' },
];

const columns = [
    { label: LB2BFullName, fieldName: 'Contact.Name'},   
    { label: LB2BEmailId, fieldName: 'Contact.Email'},
    { label: LB2BTitle, fieldName: 'Contact.Title'},
    { label: LB2BActive, fieldName: 'IsActive', type: 'boolean' },
    { label: LB2BUserName, fieldName: 'Username' },
    {
        type: 'action',
        typeAttributes: { rowActions: actions }
    }
];

const detailsActions = [
    
    { label: LB2BRemove, name: 'delete' },
];

export default class Lb2bUserManagement extends LightningElement {
    @api effectiveAccountId;
    @api parentRecordId;
    @api recordId;
    userId;
    _modalHeading;
    _profile;
    error;
    records;
    languages;
    @track timezones;
    contacts=[];
    currentUserAccount;
    isModalOpen = false;
    isAddMember = false;
    isAddEditMember = false;
    isloading = false;
    isEditMember = false;
    isaddMemberloading = false;
    newUserId;
    isModified = false;
    @api spinnerText;
    @api createEditObj = {};
    @track dataTableListColumns = columns;

    label = {
        LB2BShip_To,
        LB2BAccount,
        LB2BAddMember,
        LB2BBasicInformation,
        LB2BContactInformation,
        LB2BLangLocaleSettings, 
        LB2BAccountsAssignments, 
        LB2BSave,
        LB2BCancel,
        LB2BResetPassword, 
        LB2BResetPasswordMessage,
        LB2BEditUser,
        LB2BNewUser,
        LB2BApplyAllAccountsMessage,
        LB2BApplyAllAccounts,
        LB2BConfirm,
        LB2BApplyAllAssignments,
        LB2BNext,
        LB2bPrevious,
        LB2BFullName,
        LB2BNoAssignment
        
    }

    soldToShipToAccColumns = [
       
        { label: LB2BSoldToNumber, fieldName: 'SoldToSapAccNum'},
        { label: LB2BSoldToAddress, fieldName: 'SoldToSapAccName'},
        { label: LB2BShipToNumber, fieldName: 'ShipToSapAccNum'},
        { label: LB2BShipToAddress, fieldName: 'ShipToSapAccName'},   
     
        {   
            label: LB2BEditAssignments, 
            type: 'action',
            typeAttributes: { rowActions: detailsActions },
        }
    ];


    fields = [FirstName, LastName, Email, Username,
        Title,Alias,CommunityNickname,IsActive,ProfileId,LanguageLocaleKey,TimeZoneSidKey];

    @wire(getPicklistValues, {
        recordTypeId: '012000000000000AAA',
        fieldApiName: ProfileId
    })
    wiredProfileValues({
        data,
        error
    }) {
        if (data) {
            this.profiles = data.values;
            this.error = undefined;
        } else if (error) {
            console.log(error);
            this.error = error;
        }
    }
    
    @wire(getPicklistValues, {
        recordTypeId: '012000000000000AAA',
        fieldApiName: TimeZoneSidKey
    })
    wiredTimezoneValues({
        data,
        error
    }) {
        if (data) {
            this.timezones = data.values;
            this.error = undefined;
        } else if (error) {
            console.log(error);
            this.error = error;
        }
    }

    @wire(getPicklistValues, {
        recordTypeId: '012000000000000AAA',
        fieldApiName: LanguageLocaleKey
    })
    wiredLanguages({
        data,
        error
    }) {
        if (data) {
            this.languages = data.values;
            this.error = undefined;
        } else if (error) {
            console.log(error);
            this.error = error;

        }
    }

    options = [
            { label: 'LB2B Buyer', value: '00e3c000001H2ESAA0' },
            { label: 'LB2B Store Admin', value: '00e3c000001H2ENAA0' },
            { label: 'LB2B Requestor view only', value: '00e3c000001H2EIAA0' }
        ];

   get helpText(){
       return this.spinnerText ? this.spinnerText : 'Loading spinner'
   }

    @wire(getRecord, { recordId: Id, fields: [userAccountId]}) 
    userDetails({error, data}) {
        if (data) {
            this.currentUserAccount = data.fields.AccountId.value;
            this.callGetUserDetails(this.currentUserAccount);
        } else if (error) {
            this.error = error ;
        }
    }

        /** @type User Input} */
        apexInputWrapper = {

            FirstName: true,
            Email: null,
            Username: null,
            CommunityNickname: null,
            Title: null,
            Alias: null,
            profile: null,
            LanguageLocaleKey: null,
            TimeZoneSidKey: null,
            // contactFirstName: null,
            // contactTitle: null,
            // contactLastName: null,
            // contactEmail: null,
            isEditUser: false

        };

    connectedCallback(){
        this.resetInputWrapper();
    }

    resetInputWrapper(){
        this.apexInputWrapper.FirstName =  null;
        this.apexInputWrapper.LastName =  null;
        this.apexInputWrapper.Email =  null;
        this.apexInputWrapper.Username =  null;
        this.apexInputWrapper.CommunityNickname =  null;
        this.apexInputWrapper.Title =  null;
        this.apexInputWrapper.Alias =  null;
        this.apexInputWrapper.profile =  null;
        this.apexInputWrapper.LanguageLocaleKey =  null;
        this.apexInputWrapper.TimeZoneSidKey =  null;
        this.apexInputWrapper.isEditUser =  false;
        this._profile = null;
    }

    getUserSapAccInfo(Id){
        getUserSapAccInfo({
            userId:Id
        })
         .then(result => {
            this.sapAccountInfo = result;
            console.log('sap result >>>',result);
            let tempRecords = result.map( row => {
                if(row != undefined){
                    return { ...row, 
                        ShipToSapAccName: row.Ship_To_SAP_Account__r != undefined ? row.Ship_To_SAP_Account__r.Name : '',
                        SoldToSapAccName: row.Sold_To_SAP_Account__r != undefined ? row.Sold_To_SAP_Account__r.Name : '',
                        ShipToSapAccNum: row.Ship_To_SAP_Account__r != undefined ? row.Ship_To_SAP_Account__r.Clean_SAP_Number__c : '',
                        SoldToSapAccNum:  row.Sold_To_SAP_Account__r != undefined ? row.Sold_To_SAP_Account__r.Clean_SAP_Number__c : ''
                    };
                } 
            });
            this.soldToShipToList = tempRecords;
            this.initialRecords = tempRecords;
            console.log(' this.initialRecords: ',  this.initialRecords);
            this.isNoAssignments = this.initialRecords.length >=1 ? false : true;
            //for pagination
            this.records = tempRecords;
            this.totalRecords = tempRecords.length;
            this.paginationAvailable = this.totalRecords > 10 ? true : false;//to hide pagination when records less than 10
            this.paginationHelper();
         })
         .catch(error => {
            console.log('SoldTo ShipTo list error ', error)
         })   
    } 

    callGetUserDetails(data){
        this.isloading = true;
        console.log('Id >>>',data)
        getUserDetails(
            { accountId: data } 
        )
        .then((result) => {
        console.log('result getUserDetails >>>', result );
        this.userDetailsResult = result;
        let contactsArray=[];
        for (let row of result) {
            
            const flattenedRow = {}
            let rowKeys = Object.keys(row); 
            rowKeys.forEach((rowKey) => {
                const singleNodeValue = row[rowKey];
                if(singleNodeValue.constructor === Object){
                    this._flatten(singleNodeValue, flattenedRow, rowKey)        
                }else{
                    flattenedRow[rowKey] = singleNodeValue;
                }});
                contactsArray.push(flattenedRow);
            }
        this.isloading = false;  
        this.contacts = contactsArray;
        console.log('contacts flattened >>>',this.contacts)
        })
        .catch((err) => {
            this.isloading = false; 
            console.log('err >>>',err);
        });
    }
    _flatten = (nodeValue, flattenedRow, nodeName) => {        
        let rowKeys = Object.keys(nodeValue);
        rowKeys.forEach((key) => {
            let finalKey = nodeName + '.'+ key;
            flattenedRow[finalKey] = nodeValue[key];
        })
    }


    handleRowAction(event) {
        const actionName = event.detail.action.name;
        console.log('row action >>>',actionName)
        const row = event.detail.row;
        switch (actionName) {
            case 'deactivate':
                // this.handleDeactivate(event.detail.row.Id);
                this.deactivateUserId = event.detail.row.Id;
                this.activateDeactivate();
                break;
            case 'edit':
                this.editRowDetails(event.detail.row.Id);
                this.isdeactivateAction = false;
                this.addNewMember = false;
                break;
            case 'reset_Password':
                this.isModalOpen = true;
                this.userId = event.detail.row.Id;
                this.isdeactivateAction = false;
                break;
            case 'delete':
                this.deleteRow(event.detail.row.Id);
                break;    
            default:
        }
    }


    createNewAssignment(userId,data){
        this.createEditObj = {
            createEditModal : true,
            
            record : {
               // Id: undefined,
                User__c: userId,
                // Sold_To_SAP_Account__c:undefined,
                // Ship_To_SAP_Account__c:undefined,
                edit: data == true ? true : false,
                newUser: data == false ? true : false
            }
        }
        if (data === false) {
            this.addNewMember = true;
        }
        this.isModalOpen = false;
    }


    soldToShipToList;
    editRowDetails(id){
        
        this.isAddEditMember = true;
        this.isEditMember = true;
        // this._modalHeading = LB2BEditMember;
        this._modalHeading = LB2BEditUser;
        this.isAddMember = false;
        this.userId = id;
        editUser({
            userId : id
        }).then((result) => {
            this.isloading = false;
            console.log('result >>>',result);
            this.apexInputWrapper.FirstName = result.FirstName;
            this.apexInputWrapper.LastName = result.LastName;
            this.apexInputWrapper.Alias = result.Alias;
            this.apexInputWrapper.Username = result.Username;
            this.apexInputWrapper.IsActive = result.IsActive;
            this.apexInputWrapper.CommunityNickname = result.CommunityNickname;
            this.apexInputWrapper.Email = result.Email;
            this.apexInputWrapper.Title = result.Title;
            this.apexInputWrapper.ProfileId = result.ProfileId;
            this.apexInputWrapper.LanguageLocaleKey = result.LanguageLocaleKey;
            this.apexInputWrapper.TimeZoneSidKey = result.TimeZoneSidKey;
            // this.apexInputWrapper.contactFirstName = result.Contact.FirstName;
            // this.apexInputWrapper.contactTitle = result.Contact.Title;
            // this.apexInputWrapper.contactLastName = result.Contact.LastName;
            // this.apexInputWrapper.contactEmail = result.Contact.Email;
            this.apexInputWrapper.LanguageLocaleKey = result.LanguageLocaleKey;
            this.apexInputWrapper.TimeZoneSidKey = result.TimeZoneSidKey;
            if(result.Profile_Name__c == 'LB2B Buyer'){
                this._profile = this.options[0].label;
            } else if(result.Profile_Name__c == 'LB2B Store Admin'){
                this._profile = this.options[1].label;
            } else {
                this._profile = this.options[2].label;
            }
            this.apexInputWrapper.isEditUser = true;

           this.getUserSapAccInfo(id);   
           this.createNewAssignment(id,true);  

            })
            .catch((err) => {
                console.log('err >>>',err);
            });
    }

    deleteRow(id) { 
        console.log('id to delete row: ', id) ;
        deleteRecord(id)
            .then((result) => {
                console.log('result for deleteRow: ', result);
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Record deleted',
                        variant: 'success'
                    })
                );
                this.getUserSapAccInfo(this.userId);
                this.isModified = true;
            })
            .catch(error => {
                console.log('error for deleteRow: ', error);
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error deleting record',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            });
    }

    handleDeactivate(id){
        this.isloading = true;
        deactivateUser({
            userId : id
        }).then((result) => {
            console.log(' result of deactivateUser >>>>', result);
            this.isloading = false;
            this.callGetUserDetails(this.currentUserAccount);
            // this.isModalOpen = false;
            })
            .catch((err) => {
                this.isloading = false;
                console.log('err >>>',err);
            });
    }

    handleResetPassword(event){
        console.log('this.userId >>>',this.userId);
        this.isloading = true;
        resetPassword({
            userId : this.userId
        }).then((result) => {
            this.isloading = false;
            this.isModalOpen = false;
            })
            .catch((err) => {
                console.log('err >>>',err);
            });
    }

    handleToggleOpenClick(event) {
        this.isModalOpen = false;
        this.isAddEditMember = false;
        this.addNewMember = false;
        this.resetInputWrapper();
    }

    handleAddMember(){
        this.isAddEditMember = true;
        this.isAddMember = true;
        this._modalHeading = LB2BNewUser;
        this.isEditMember = false;

    }

    handleSaveUser(){
        console.log('this.apexInputWrapper',JSON.parse(JSON.stringify(this.apexInputWrapper)));
        // this.addNewMember = true;
        let flag= true;
        Object.keys(this.apexInputWrapper).forEach(key => {
            console.log('key:', key, ' values: ', this.apexInputWrapper[key]);
            if (key === 'FirstName' && this.apexInputWrapper[key] == null) {
                flag = false;
                this.getToasterErrorMsg('Please fill the required fields');
            } else if (key === 'LastName' && this.apexInputWrapper[key] == null) {
                flag = false;
                this.getToasterErrorMsg('Please fill the required fields');
            } else if (key === 'Alias' && this.apexInputWrapper[key] == null) {
                flag = false;
                this.getToasterErrorMsg('Please fill the required fields');
            } else if (key === 'Username' && this.apexInputWrapper[key] == null) {
                flag = false;
                this.getToasterErrorMsg('Please fill the required fields');
            } else if (key === 'Email' && this.apexInputWrapper[key] == null) {
                flag = false;
                this.getToasterErrorMsg('Please fill the required fields');
            } else if (key === 'Title' && this.apexInputWrapper[key] == null) {
                flag = false;
                this.getToasterErrorMsg('Please fill the required fields');
            } else if (key === 'Nickname' && this.apexInputWrapper[key] == null) {
                flag = false;
                this.getToasterErrorMsg('Please fill the required fields');
            } else if (key === 'ProfileId' && this.apexInputWrapper[key] == null) {
                flag = false;
                this.getToasterErrorMsg('Please fill the required fields');
            } else if (key === 'TimeZoneSidKey' && this.apexInputWrapper[key] == null) {
                flag = false;
                this.getToasterErrorMsg('Please fill the required fields');
            } else if (key === 'LanguageLocaleKey' && this.apexInputWrapper[key] == null) {
                flag = false;
                this.getToasterErrorMsg('Please fill the required fields');
            }
        })
        console.log('flag ; ', flag);
        let searchCriteriaString = JSON.stringify(this.apexInputWrapper);
        // this.apexInputWrapper.isEditUser = true ? (this.spinnerText = LB2BUpdateUserMessage ) : (this.spinnerText = LB2BCreateUserMessage );
        this.apexInputWrapper.isEditUser = false;
        // this.isaddMemberloading = true;
        console.log('this.userId: ------> ', this.userId);
        if (flag) {
            this.isaddMemberloading = true;
            addUser({
                userData : searchCriteriaString,
                accountId : this.currentUserAccount,
                uId : this.userId
            }).then((result) => {
                console.log('result of addUser:---->', result);
                if(result == null){
                    setTimeout(() => {
                        this.callNewUser(this.apexInputWrapper.isEditUser);
                    }, 20000);
                } else if(result.includes('Duplicate')) {
                    let errMsg =result;
                    this.getToasterErrorMsg(errMsg);
                    this.isaddMemberloading = false;
                }
            }).catch((err) => {
                    this.isaddMemberloading = false;
                    console.log('add user err >>>',err);
            });
        }   
    }

    callNewUser(data){
        newUser()
        .then((result) => {
            console.log('user result',result);
            console.log('user this.apexInputWrapper.Email', this.apexInputWrapper.Email);
           if(!data){
            if(result.Email == this.apexInputWrapper.Email){
                console.log('inside if email is confirmed')
                this.newUserId = result.Id;
                console.log('newUserId >>>',this.newUserId);

                this.callGetUserDetails(this.currentUserAccount);
                this.isEditMember = true;
                // this._modalHeading = LB2BEditMember;
                this._modalHeading = LB2BEditUser;
                this.isaddMemberloading = false;
                this.resetInputWrapper();
                this.createNewAssignment(this.newUserId,false);
            } else {
                this.getToasterErrorMsg('User Creation Error');
                this.isaddMemberloading = false;
            }
           } else {
            this.newUserId = result.Id;
            console.log('newUserId >>>',this.newUserId);

            this.callGetUserDetails(this.currentUserAccount);
            this.isEditMember = true;
            // this._modalHeading = LB2BEditMember;
            this._modalHeading = LB2BEditUser;
            this.isAddEditMember = false;
            this.isaddMemberloading = false;
            this.resetInputWrapper();
            this.createNewAssignment(this.newUserId,true);
           }
            
        })
        .catch((err) => {
            this.isaddMemberloading = false;
            console.log('err >>>',err);
        });
    }

    handleFirstName(event){
        this.apexInputWrapper.FirstName = event.detail.value;
    }
    handleLastName(event){
        this.apexInputWrapper.LastName = event.detail.value;
    }
    handleAlias(event){
        this.apexInputWrapper.Alias = event.detail.value;
    }
    handleUsername(event){
        this.apexInputWrapper.Username = event.detail.value;
    }
    handleIsActive(event){
        this.apexInputWrapper.IsActive = event.target.checked;
    }
    handleCommunityNickname(event){
        this.apexInputWrapper.CommunityNickname = event.detail.value;
    }
    handleEmailChange(event){
        this.apexInputWrapper.Email = event.detail.value.toLowerCase();
    }
    handleTitleChange(event){
        this.apexInputWrapper.Title = event.detail.value;
    }
    handleProfileChange(event){
        this.apexInputWrapper.ProfileId = event.detail.value;
    }
    handleLanguageChange(event){
        this.apexInputWrapper.LanguageLocaleKey = event.detail.value;
    }
    handleTimeZoneChange(event){
        this.apexInputWrapper.TimeZoneSidKey = event.detail.value;
    }
    // handleContactFirstName(event){
    //     this.apexInputWrapper.contactFirstName = event.detail.value;
    // }
    // handleContactLastName(event){
    //     this.apexInputWrapper.contactLastName = event.detail.value;
    // }
    // handleContactEmail(event){
    //     this.apexInputWrapper.contactEmail = event.detail.value;
    // }
    // handleContactTitle(event){
    //     this.apexInputWrapper.contactTitle = event.detail.value;
    // }

    getToasterErrorMsg(errMsg) {
        const event = new ShowToastEvent({
            title: errMsg,
            variant: 'error',
            mode: 'dismissable'
        });
        this.dispatchEvent(event);
    }

    hanldeCloseModal(event) {
        console.log('handle close modal: ', JSON.stringify(event));
        console.log('handle close modal11: ', event.detail);
        // this.isModified = event.detail;
        // this.isCreateEdit = false;
       // this.isAddEditMember = false;
        this.callGetUserDetails(this.currentUserAccount);
        console.log('id >>>',this.userId , 'event.detail: ', event.detail);
        // this.getUserSapAccInfo(this.userId);
        this.getUserSapAccInfo(event.detail);  
    }


    //code for pop up 
    @track isdeactivateAction = false; //added
    @track deactivateUserId;
    @track userDetailsResult;
    @track popMessage;
    @track isApplyAssignments = false;
    @track isPopUploading = false;

    activateDeactivate(){
        for ( let i = 0; i <= this.userDetailsResult.length; i++) {
            if (JSON.parse(JSON.stringify(this.userDetailsResult[i].Id)) === this.deactivateUserId ) {
                if(JSON.parse(JSON.stringify(this.userDetailsResult[i].IsActive))) {
                    this.popMessage = LB2BDeactivateUser;
                    break;
                } else {
                    this.popMessage = LB2BActivateUser;
                    break;
                }
            }
        }
        this.isdeactivateAction = true;
        this.isModalOpen = true;
    }

    handleCancel() {
        this.isModalOpen = false;
        this.isdeactivateAction = false;
        this.isApplyAssignments = false;
    }

    handleDeactivateAction() {
        this.isModalOpen = false;
        this.handleDeactivate(this.deactivateUserId);
    }

    handleAllAssignments() {
        this.isApplyAssignments = true; 
        // this.isloading = true; 
        this.isPopUploading = true;  
    }

    applyOwnerAssignments() {
        ownerUserErpAccounts({
            userId : this.userId
        }).then((result) => {
            console.log('result of ownerUserErpAccounts >> ',result);
            this.hanldeCloseModal();
        }).catch((err) =>{
            console.log('err of ownerUserErpAccounts >> ',err);
        })
    }

    handleCancelAssignments() {
        this.isApplyAssignments = false;
        // this.isloading = false;
        this.isPopUploading = false;
    }


    // JS function to handel pagination logic
    records = []; //All records available in the data table
    columns = []; //columns information available in the data table
    totalRecords = 0; //Total no.of records
    pageSize = 10; //No.of records to be displayed per page
    totalPages; 
    pageNumber = 1;
    paginationAvailable = false;
    initialRecords;
    isNoAssignments = false;
    addNewMember = false;

    paginationHelper() {
        this.soldToShipToList = [];
        // calculate total pages
        this.totalPages = Math.ceil(this.totalRecords / this.pageSize);
        // set page number 
        if (this.pageNumber <= 1) {
            this.pageNumber = 1;
        } else if (this.pageNumber >= this.totalPages) {
            this.pageNumber = this.totalPages;
        }
        // set records to display on current page 
        for (let i = (this.pageNumber - 1) * this.pageSize; i < this.pageNumber * this.pageSize; i++) {
            if (i === this.totalRecords) {
                break;
            }
            this.soldToShipToList.push(this.records[i]);
        }
    }

    previousPage() {
        this.pageNumber = this.pageNumber - 1;
        this.paginationHelper();
    }
    nextPage() {
        this.pageNumber = this.pageNumber + 1;
        this.paginationHelper();
    }

    get bDisableFirst() {
        return this.pageNumber == 1;
    }
    get bDisableLast() {
        return this.pageNumber == this.totalPages;
    }

    handleSearch( event ) {
        const searchKey = event.target.value.toLowerCase();

        if ( searchKey ) {
            this.soldToShipToList = this.initialRecords;
            if ( this.soldToShipToList ) {
                let recs = [];
                for ( let rec of this.soldToShipToList ) {
                    let valuesArray = Object.values( rec );
                    for ( let val of valuesArray ) {
                        let strVal = String( val );
                        if ( strVal ) {
                            if ( strVal.toLowerCase().includes( searchKey ) ) {
                                recs.push( rec );
                                break;
                            }
                        }
                    }
                }
                this.soldToShipToList = recs;
             }
        }  else {
            this.soldToShipToList = this.initialRecords;
        }        

    }

   
}