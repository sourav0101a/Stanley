/**
 * Modified by Dilvar Singh on  09/14/2022.
 */

import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import Lb2bOrdersCount from '@salesforce/label/c.Lb2bOrdersCount';
import LB2BHas from '@salesforce/label/c.LB2BHas';
import {HomePageEvent} from 'c/lb2bDataLayer';  //added

export default class Lb2bOrderOnHoldItem extends NavigationMixin(LightningElement) {
    @api sapNumber;
    @api accountName;
    @api count;

    label = {
        Lb2bOrdersCount,
        LB2BHas
    };

    navigateToOnHold() {
        let url = window.location.origin + window.location.pathname;
        url = url + 'orders-on-hold?soldtonumber=' + this.sapNumber;
        // console.log('navigation url: ', url);
        this.navigateToWebPage(url);
        this.MoveHomePageToDataLayer('Order on hold');  //added
    }

    navigateToWebPage(url) {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url
            }
        });
    }

     //added
     MoveHomePageToDataLayer(data){
        HomePageEvent('select_content','Home',data);
    }
}