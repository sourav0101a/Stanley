import { LightningElement, api, wire, track } from 'lwc';
import { fireEvent } from 'c/lb2bPubSub';
import { registerListener } from 'c/lb2bPubSub';
import { CurrentPageReference } from 'lightning/navigation';

import isAccountSuperUser from '@salesforce/customPermission/Account_Superuser';

// Salesforce fields
import UserId from '@salesforce/user/Id';

// Apex classes
import getUserAccounts from '@salesforce/apex/LB2BAccountSelectorController.getUserAccounts';

// Translation labels
import AccountName from '@salesforce/label/c.LB2BAccountName';
import Address from '@salesforce/label/c.LB2BAddress';
import AccountNumber from '@salesforce/label/c.LB2BAccountNumber';
import CompanyName from '@salesforce/label/c.LB2BCompanyName';
import AccountSelectPrompt from '@salesforce/label/c.LB2BAccountSelectPrompt';
import SelectAccount from '@salesforce/label/c.LB2BSelectAccount';
import PleaseChooseOne from '@salesforce/label/c.LB2BPleaseChooseOne';

// CSS loads
import GlobalCSS from '@salesforce/resourceUrl/lb2b_global';
import { loadStyle } from 'lightning/platformResourceLoader';

const EVENT_NAME = 'accountDependency';

export default class Lb2bUserManagementAccountSelector extends LightningElement {

    label = {
        AccountName,
        Address,
        AccountNumber,
        CompanyName,
        AccountSelectPrompt,
        SelectAccount,
        PleaseChooseOne
    };

    @wire(CurrentPageReference) pageRef;

    incomingDependencyData;
    
    outgoingDependencyData;

    /**
     * Indicates whether this component is functioning as a sold to or ship to.
     *
     * Possible values: 'SoldTo' or 'ShipTo' ONLY.
     *
     * @type {string}
     */
    @api accountType;

    /**
     * Indicates where this component is being used.
     *
     * Possible values or 'Cart' or 'Query'
     */
    @api usage;

    /**
     * ID of the cart
     *
     * @type {string}
     */
    @api cartId;

    @api customLabel;

    //@track hideAccount = false;

   // ishandleChange = false;

    /**
     * Wrapper for account data to show on the user interface
     *
     * @type {AccountInfo}
     */
   // _selectedErpAccount = '';

    get selectorLabel() {
        if (this.customLabel) {
            return this.customLabel;
        } else {
            return this.label.SelectAccount;
        }
    }

    /**
     * The name of the company for the selected Sold To SAP Account.
     *
     * @type {string}
     */
    selectedCompanyName;

    /**
     * Selected SAP Account SFDC Id to send to the cart.  Depending on the account type,
     * this could be used for the sold to or ship to account.
     *
     * @type {string}
     */
    selectedErpAccountId;

    /**
     * List of User SAP Accounts retrieved from salesforce
     *
     * @type {Array<UserAccount>}
     */
    userErpAccountList;

    /**
     * Options to be displayed in the dropdown list
     */
    _selectOptions = [];

   // hasAccess = isAccountSuperUser;

    // pointOfPurchase;
    // @track isPop;

    async connectedCallback() {
        registerListener(EVENT_NAME, this.handleDependencyEvent, this);
        this.getAccountOptions().then((result) => this.optionPopulate(result, true));       
    }

    renderedCallback() {
        loadStyle(this, GlobalCSS);
    }

    // #region Pubsub communication
    fireDependencyEvent() {
        fireEvent(this.pageRef, EVENT_NAME, this.outgoingDependencyData);

        if (this.outgoingDependencyData.accountSelected == 'null') {
            this.optionPopulate(this.userErpAccountList, false);
        }
    }

    handleDependencyEvent(dependencyData) {
        // If this dropdown sent the event, we can ignore it
        if (dependencyData.fromAccountType == this.accountType) {
            return;
        }

        this.incomingDependencyData = dependencyData;
        this.populateOptionsFromDependency();
    }
    
    populateOptionsFromDependency() {
        let dependencyOptions = [];

        if (this.incomingDependencyData.accountSelected == 'null') {
            dependencyOptions = this.userErpAccountList;
        } else {
            if (this.accountType == 'SoldTo') {
                dependencyOptions = this.userErpAccountList.filter(
                    (acct) =>
                        acct.shipToAccountInfo.sapAccountId ==
                        this.incomingDependencyData.accountSelected
                );
            } else if (this.accountType == 'ShipTo') {
                dependencyOptions = this.userErpAccountList.filter(
                    (acct) =>
                        acct.soldToAccountInfo.sapAccountId ==
                        this.incomingDependencyData.accountSelected
                );
            }
        }

        this.optionPopulate(dependencyOptions, false);

        if (this.incomingDependencyData.accountSelected == 'null') {
            this.template.querySelector('c-lb2b-searchable-dropdown').setValue('');
            this.selectedErpAccountId = undefined;
        }

        this.incomingDependencyData = {
            fromAccountType: 'type',
            accountSelected: 'null'
        };
    }

    async getAccountOptions() {
        return (
            getUserAccounts({ userId: UserId })
                .then((result) => {
                    return result;
                })
                .catch((error) => {
                    console.error(error);
                    return [];
                })
        );
    }

    /**
     * Provides the dropdown with its initial data before considering any default options,
     * currently selected data in the cart, or dependency data.
     *
     * @param {Array<UserAccount>} res
     * A list of User Accounts
     *
     * @param {boolean} updateErpAccountList
     * Whether or not to update the full list of User Accounts.  Updating
     * this should only happen during the Connected Callback of the lifecycle.  Future
     * updates will result in instability
     */
    optionPopulate(res, updateErpAccountList) {
        let options = [];
        let sfIds = [];
        let shipTo = [];

        for (let userAcct of res) {
            // Select the correct SAP account based on the account type
            let myAcct = this.getSapAccount(userAcct, undefined);

            // Due to how we are storing data, duplicates are possible and expected to happen,
            // so lets only grab one of each account
            if (sfIds.includes(myAcct.sapAccountId)) {
                // We already have this account in this drop down, we can skip it
                continue;
            } else {
                sfIds.push(myAcct.sapAccountId);
            
                let description = '';
                if (myAcct.streetAddress != undefined) {
                    description =
                        myAcct.streetAddress + ' ' + myAcct.city + ' ' + myAcct.postalCode;
                }

                if (myAcct.streetAddress != undefined && myAcct.brand != undefined) {
                    description += ' - ' + myAcct.brand;
                }

                if (myAcct.streetAddress == undefined && myAcct.brand != undefined) {
                    //description = myAcct.brand;
                    description = myAcct.city + ' ' + myAcct.postalCode + ' - ' + myAcct.brand;
                }
                if (myAcct.streetAddress == undefined && myAcct.brand == undefined) {
                    description = myAcct.city + ' ' + myAcct.postalCode;
                }
                if (
                    myAcct.streetAddress == undefined &&
                    myAcct.brand == undefined &&
                    myAcct.city == undefined &&
                    myAcct.postalCode == undefined
                ) {
                    description = null;
                }

                options.push({
                    label: this.cleanSapNumber(myAcct.sapNumber) + ' - ' + myAcct.accountName,
                    description: description,
                    value: this.accountType + '|' + myAcct.sapAccountId + '|' + userAcct.isPersonal,
                    search: myAcct.searchableText
                });
            }
        }

        if (updateErpAccountList) {
            this.userErpAccountList = res;
        }

        // Set the options for the drop down now
        this._selectOptions = [];
        this.selectOptions = [...options];
        const acctSelector = this.template.querySelector('c-lb2b-searchable-dropdown');
        acctSelector.setOptions(options);
    }

    /**
     * Event handler for when the dropdown box selection changes.
     * This updates the component's api property and displays the account information
     * on the screen.
     */
    handleAccountChanged(event) {
        //this.ishandleChange = true;
        const selection = event.detail.value;
        const valueArr = selection.split('|');

        this.outgoingDependencyData = {
            fromAccountType: this.accountType,
            accountSelected: valueArr[1],
            isPersonal: valueArr[2],
            sapNumber:event.detail.label
        };
        this.fireDependencyEvent();

        if (valueArr[1] == 'null') {
            this.selectedErpAccountId = undefined;
            this.selectedErpAccount = undefined;
        } else {
          
            this.selectedErpAccountId = valueArr[1];
            this.selectedErpAccount = this.getErpAccountById(this.selectedErpAccountId);

            if (valueArr[0] == 'SoldTo') {
                // Set company name for sold to selection
                let userAcct = this.userErpAccountList.filter(
                    (a) => a.soldToAccountInfo.sapAccountId == this.selectedErpAccountId
                )[0];
                this.selectedCompanyName = userAcct.companyName;
            }
        }
       
        const evt = new CustomEvent('accountselected', {
            detail: this.accountType + '|' + this.selectedErpAccountId + '|' + this.selectedErpAccount.sapNumber
        });
        this.dispatchEvent(evt);
      
    }

    /**
     * Finds and returns the correct AccountInfo instance based on a Salesforce ID
     * and the account type of this dropdown.
     *
     * @param {string} salesforceId
     * The Salesforce ID of the SAP Account
     *
     * @returns {AccountInfo} The matching AccountInfo instance.
     */
    getErpAccountById(salesforceId) {
        if (salesforceId == 'null') {
            return null;
        } else {
            return this.getSapAccount(undefined, salesforceId);
        }
    }

    /**
     * Sends a request to the apex xontroller to update (or reset) the Cart's
     * SAP Account info.
     *
     * @param {AccountInfo} selection
     * @param {boolean} resetFlag
     */
   
    getSapAccount(wrapper, sfdcId) {
        if (this.accountType != 'SoldTo' && this.accountType != 'ShipTo') {
            return null;
        }

        if (wrapper) {
            if (this.accountType == 'SoldTo') {
                return wrapper.soldToAccountInfo;
            } else if (this.accountType == 'ShipTo') {
                return wrapper.shipToAccountInfo;
            }
        } else if (sfdcId) {
            let filterRes;
            if (this.accountType == 'SoldTo') {
                return (filterRes = this.userErpAccountList.filter(
                    (userAcct) => userAcct.soldToAccountInfo.sapAccountId == sfdcId
                )[0]).soldToAccountInfo;
            } else if (this.accountType == 'ShipTo') {
                return (filterRes = this.userErpAccountList.filter(
                    (userAcct) => userAcct.shipToAccountInfo.sapAccountId == sfdcId
                )[0]).shipToAccountInfo;
            }
        }
    }

    cleanSapNumber(acctNumber) {
        return acctNumber.replace(/\b0+/g, '');
    }

    @api 
    callSetValue(data) {
        const acctSelector = this.template.querySelector('c-lb2b-searchable-dropdown');
        acctSelector.setValue(data);
    }
    
}