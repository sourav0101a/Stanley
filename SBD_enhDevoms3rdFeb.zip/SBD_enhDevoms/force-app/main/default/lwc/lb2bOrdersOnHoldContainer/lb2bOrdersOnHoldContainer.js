/**
 * @description       : 
 * @author            : Stefanie Elling
 * @group             : 
 * @last modified on  : 09-14-2022
 * @last modified by  : Dilvar Singh
**/
import { LightningElement } from 'lwc';

import ICON from '@salesforce/resourceUrl/LB2B_Store_Icons';
import USER_ID from '@salesforce/user/Id';
import { NavigationMixin } from 'lightning/navigation';
import getOrdersOnHold from '@salesforce/apex/LB2BOrdersOnHoldHomepageController.getOrders';

import OrdersNeedAttention from '@salesforce/label/c.LB2BOrdersOnHoldNeedAttention';
import ViewAll from '@salesforce/label/c.LB2BViewAllOrdersOnHold';
import MailingAddress from '@salesforce/schema/Contact.MailingAddress';

import hasPermission from '@salesforce/customPermission/Internal_Sales_Rep';
import {HomePageEvent} from 'c/lb2bDataLayer';  //added
import LOCALE from '@salesforce/i18n/locale';
export default class Lb2bOrdersOnHoldContainer extends NavigationMixin(LightningElement) {
    iconURL = ICON;
    userId = USER_ID;
    isLoading = false;
    limitOrders = [];
    tileWidth;
    locale = LOCALE;

    label = {
        OrdersNeedAttention,
        ViewAll
    };

    ordersOnHold = [];

    connectedCallback() {
        this.isLoading = true;
        getOrdersOnHold({ userId: this.userId })
            .then((result) => {
                this.isLoading = false;
                this.ordersOnHold = result;
                for (let i = 0; i < Math.min(this.ordersOnHold.length, 5); i++) {  
                    this.limitOrders.push(this.ordersOnHold[i]);
                }
            })

            .catch((error) => {
                 console.error('Error:', error);
            });
    }

    get doShowOrdersOnHold() {
        return this.ordersOnHold.length > 0 && this.locale == 'en-US' && !hasPermission;
    }

    navigateToOrdersOnHold() {
        let url = window.location.href.split('/s/');

        let newUrl = url[0] + '/s/orders-on-hold';
        this.navigateToWebPage(newUrl);
        this.MoveHomePageToDataLayer('Order on hold');  //added
    }

    navigateToWebPage(url) {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url
            }
        });
    }

    get ordersOnHoldLimit() {
        return limitOrders;
    }

    MoveHomePageToDataLayer(data){
        HomePageEvent('select_content','Home',data);
    }
}