import { LightningElement, api, wire, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { fireEvent } from 'c/lb2bPubSub';
import { CurrentPageReference } from 'lightning/navigation';
import getOrderDetail from '@salesforce/apex/LB2BHoldOrderItemsController.getOrderLineItems';
import LB2BTotal from '@salesforce/label/c.LB2BTotal';
import LB2BSBDPrice from '@salesforce/label/c.LB2BSBDPrice';
import LB2BQuantity from '@salesforce/label/c.LB2BQuantity';
import LB2BCustomerPrice from '@salesforce/label/c.LB2BCustomerPrice';
import LB2BSku from '@salesforce/label/c.LB2BSku';
import LB2BAcceptAll from '@salesforce/label/c.LB2BAcceptAll';
import LB2BRejectPriceIsCurrect from '@salesforce/label/c.LB2BRejectPriceIsCurrect';
import LB2BRejectCancel from '@salesforce/label/c.LB2BRejectCancel';
import LB2BAccept from '@salesforce/label/c.LB2BAccept';
import LB2BOrderOnHold from '@salesforce/label/c.LB2BOrderOnHold';
import LB2BSubmit from '@salesforce/label/c.LB2BSubmit';
import LB2BSelectItems from '@salesforce/label/c.LB2BSelectItems';
import LB2BError from '@salesforce/label/c.LB2BError';
import GlobalCSS from '@salesforce/resourceUrl/lb2b_global';
import { loadStyle } from 'lightning/platformResourceLoader';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { registerListener } from 'c/lb2bPubSub';
import LB2BLoading from '@salesforce/label/c.LB2BLoading';

export default class Lb2bOnHoldOrderDetail extends NavigationMixin(LightningElement) {
    holdOrders;
    MappedHoldOrders;
    recordData = [];
    mapData = [];
    // defaultValue='Accept';
    @track isLoading = true;

    @wire(CurrentPageReference) pageRef;

    label = {
        LB2BTotal,
        LB2BSku,
        LB2BSBDPrice,
        LB2BQuantity,
        LB2BCustomerPrice,
        LB2BAcceptAll,
        LB2BOrderOnHold,
        LB2BSubmit,
        LB2BSelectItems,
        LB2BLoading,
        LB2BError
    };
    currentPageReference = null;
    @api OrderNumber = null;
    @api restoredArray = undefined;
    @track hide;

    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        // console.log("inside get state paramter", currentPageReference.state.onholdorderNumber)
        if (currentPageReference) {
            this.OrderNumber = currentPageReference.state.onholdorderNumber;
            console.log(this.OrderNumber, 'order number ');
        }
    }

    handleAcceptChange(event) {
        const id = event.target.dataset.itemId;
        this.MappedHoldOrders = this.MappedHoldOrders.map((row) => ({
            ...row,
            accept: row.key === id ? event.detail.value : row.accept === undefined ? '' : row.accept
        }));
        //   (row.accept === undefined ? 'Accept':row.accept)
    }

    acceptAll() {
        this.template.querySelectorAll('.acceptall').forEach((each) => {
            each.value = 'Accept';
        });
        this.MappedHoldOrders = this.MappedHoldOrders.map((row) => ({
            ...row,
            accept: 'Accept'
        }));
    }

    connectedCallback() {
        console.log('inside connected callback ');
        getOrderDetail({
            // sapOrderNumber : '7023614206'
            sapOrderNumber: this.OrderNumber
        })
            .then((result) => {
                this.holdOrders = result;
                console.log('Real result : ', this.holdOrders);
                // To retain the values when navigated back
                this.restoredArray = JSON.parse(localStorage.getItem('selectedOptions'));
                console.log('Restored Array in CC', this.restoredArray);
                localStorage.setItem('Current Order Number', JSON.stringify(this.OrderNumber));
                if (this.restoredArray != undefined) {
                    this.MappedHoldOrders = this.restoredArray;
                    console.log('Restored Array:', this.MappedHoldOrders);
                } else {
                    this.MappedHoldOrders = Object.keys(this.holdOrders.lineItemMap).map((key) => ({
                        key: key,
                        ...this.holdOrders.lineItemMap[key]
                    }));
                    console.log('Outcome result ' + this.MappedHoldOrders);
                }
                this.isLoading = false;
            })
            .catch((error) => {
                console.error(error);
            });
    }

    renderedCallback() {
        loadStyle(this, GlobalCSS);
    }

    get getAcceptAllValues() {
        return [
            { label: LB2BAccept, value: 'Accept' },
            { label: LB2BRejectCancel, value: 'Reject - Cancel Line' },
            { label: LB2BRejectPriceIsCurrect, value: 'Reject - Our price is correct' }
        ];
    }

    naviagteToOrderConfirmation() {
        console.log('aaaaaaaaa', this.holdOrders);

        var pathname = new URL(window.location.href).pathname.split('?onholdorderNumber');
        // var pathname = (window.location.origin + window.location.pathname).split("?onholdorderNumber");
        console.log('pathname :', pathname);

        console.log('pathname : ', pathname[0]);
        let errorMsg;
        for (let i = 0; i < this.MappedHoldOrders.length; i++) {
            if (
                this.MappedHoldOrders[i].accept == '' ||
                this.MappedHoldOrders[i].accept == undefined
            ) {
                errorMsg = true;
                break;
            }
        }
        let obj = {
            poNum: this.holdOrders.poNumber,
            SoldTo: this.holdOrders.soldToNumber,
            shipTo:this.holdOrders.shipToNumber,
            shipToName:this.holdOrders.shipToName,
            mappedArray: this.MappedHoldOrders
        };
        setTimeout(() => {
            fireEvent(this.pageRef, 'arrayData', obj);
        }, 2000);
        if (errorMsg == true) {
            let msg = this.label.LB2BSelectItems;
            this.dispatchEvent(
                new ShowToastEvent({
                    title: this.label.LB2BError,
                    message: msg,
                    variant: 'error'
                })
            );
        } else {
            this.navigateToWebPage(pathname[0]);
        }
    }

    navigateToWebPage(url) {
        console.log('url : ', url);
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url:
                    url.replace('/onhold-orderdetail', '/onhold-orderconfirmation/') +
                    '?sapOrderNumber=' +
                    this.OrderNumber
                //+'?skuNumber=' + 'D24000S'
            }
        });
    }

    get ArrayLength() {
        if (this.MappedHoldOrders == undefined) {
            setTimeout(() => {
                this.hide = true;
            }, 500);
        }
        if (this.MappedHoldOrders != undefined) {
            this.hide = false;
        }
        return this.hide;
    }
}