import { LightningElement, api, wire, track } from 'lwc';
import Name from '@salesforce/schema/User.FullName__c';
import UserEmaill from '@salesforce/schema/User.Email';
import USER_ID from '@salesforce/user/Id';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import { NavigationMixin } from 'lightning/navigation';
import { CurrentPageReference } from 'lightning/navigation';
import { registerListener } from 'c/lb2bPubSub';
import LB2BAcceptReject from '@salesforce/label/c.LB2BAcceptReject';
import LB2BCustomerService from '@salesforce/label/c.LB2BCustomerService';
import LB2BSbdService from '@salesforce/label/c.LB2BSbdService';
import LB2BOrder from '@salesforce/label/c.LB2BOrder';
import LB2BPo from '@salesforce/label/c.LB2BPo';
import LB2BWhseAccount from '@salesforce/label/c.LB2BWhseAccount';
import LB2BConfirmAcceptance from '@salesforce/label/c.LB2BConfirmAcceptance';
import LB2B_Information_Icon from '@salesforce/resourceUrl/LB2B_Information_Icon';
import LB2BTotal from '@salesforce/label/c.LB2BTotal';
import LB2BSku from '@salesforce/label/c.LB2BSku';
import LB2BClose from '@salesforce/label/c.LB2BClose';
import LB2BGotoHome from '@salesforce/label/c.LB2BGotoHome';
import LB2BEmailSentBody from '@salesforce/label/c.LB2BEmailSentBody';
import LB2BEditItems from '@salesforce/label/c.LB2BEditItems';
import LB2BSendEmails from '@salesforce/label/c.LB2BSendEmails';
import LB2BSBDPrice from '@salesforce/label/c.LB2BSBDPrice';
import LB2BQuantity from '@salesforce/label/c.LB2BQuantity';
import LB2BAccount from '@salesforce/label/c.LB2BAccount';
import LB2BUserEmail from '@salesforce/label/c.LB2BUserEmail';
import LB2BCustomerPrice from '@salesforce/label/c.LB2BCustomerPrice';
import LB2BEmailDeliverabilityError from '@salesforce/label/c.LB2BEmailDeliverabilityError';
import EmailDeliverability from '@salesforce/apex/LB2BSendEmailController.EmailDeliverability';
import sendEmail from '@salesforce/apex/LB2BSendEmailController.sendEmail';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import GlobalCSS from "@salesforce/resourceUrl/lb2b_global";
import { loadStyle } from "lightning/platformResourceLoader";
import STORE_RESX from '@salesforce/resourceUrl/LB2B_Store';
import LB2BLoading from '@salesforce/label/c.LB2BLoading';

//For displaying account name 
import getSapAccountName from '@salesforce/apex/LB2BOrdersOnHoldController.getSapAccountName';
import updateOrderonHoldStatus from '@salesforce/apex/LB2BOrdersOnHoldController.updateOrderonHoldStatus';

export default class Lb2bOnHoldOrderConfirmation extends NavigationMixin(LightningElement) {

   // currentPageReference = null;
    @api subject;
    @api PoNumber;
    @api SoldTO;
    @api shipTo;
    @api shipToName;
    holdOrders;
    @api OrderNumber;
    @api cartIdFromLocalStorage;
    openModal = false;
    @api iconURL = LB2B_Information_Icon;
    UserName;
    userId = USER_ID;
    UserEmail;
    @api bodyTemplate;
    @api demo = [];
    @api accName;
    @track isLoading = true;

    label = {
        LB2BAcceptReject,
        LB2BCustomerService,
        LB2BSbdService,
        LB2BOrder,
        LB2BPo,
        LB2BWhseAccount,
        LB2BConfirmAcceptance,
        LB2BTotal,
        LB2BSku,
        LB2BSBDPrice,
        LB2BQuantity,
        LB2BCustomerPrice,
        LB2BSendEmails,
        LB2BEditItems,
        LB2BEmailSentBody,
        LB2BGotoHome,
        LB2BClose,
        LB2BEmailDeliverabilityError,
        LB2BAccount,
        LB2BUserEmail,
        LB2BLoading
    };

    logoImages = {
        dwBrand: this.getImage('dwBrand'),
        sbdblacklogores: this.getImage('sbdblacklogores')
    };
    getImage(name, type = 'jpg', prefix = 'LB2B_') {
        return STORE_RESX + '/images/' + prefix + name + '.' + type;
    }

    @wire(CurrentPageReference) pageRef;

    connectedCallback() {
        registerListener('arrayData', this.handleEvent, this);
    }

    renderedCallback() {
        loadStyle(this, GlobalCSS);
    }

    @wire(getRecord, { recordId: USER_ID, fields: [Name, UserEmaill] })
    userDetails({ error, data }) {
        if (data) {
            this.UserName = data.fields.FullName__c.value;
            this.UserEmail = data.fields.Email.value;
        } else if (error) {
            this.error = error;
        }
    }

    handleEvent(inpVal){
        console.log("inpvaal",inpVal);
        this.holdOrders = inpVal.mappedArray;
        this.PoNumber = inpVal.poNum;
        this.SoldTO = inpVal.SoldTo;
        this.shipTo = inpVal.shipTo;
        this.shipToName = inpVal.shipToName;
        this.demo.push(this.holdOrders);
        localStorage.setItem('selectedOptions', JSON.stringify(this.holdOrders));
        // For displaying account name 
        getSapAccountName({
            soldToNumber :this.SoldTO
        })
        .then(result =>{
            console.log('Orders:', result);
            this.accName = result.Name;
            this.isLoading = false;
        })
        .catch(error =>{
            console.log('error for get sold to number data', error)
        })
    }

    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        if (currentPageReference) {
            this.OrderNumber = currentPageReference.state.sapOrderNumber;
            console.log('Order numberrr' + this.OrderNumber);
        }
    }

    showModal() {
        this.openModal = true;
    }
    closeModal() {
        this.openModal = false;
    }
    navigateToHomePage() {
        let url = new URL(window.location.href).pathname.split('onhold-orderconfirmation');
        console.log('url : ', url[0]);
        this.navigateToWebPage(url[0]);
    }
    navigateToWebPage(url) {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url
            }
        });
    }

    naviagteToPreviousPage() {
        window.history.back();
    }

    emailbody() {
        let doc = '<h1>' + this.label.LB2BAcceptReject + ':' + this.OrderNumber + '</h1>';
        doc += '<p>' + this.label.LB2BSbdService + ',' + '</p>';
        doc += '<p>' + this.label.LB2BOrder + ' ' + '<b>' + this.OrderNumber + '</b>' + '</p>';
        doc += '<p>' + this.label.LB2BPo + ' ' + this.PoNumber + '</p>';
        doc +=
            '<p>' +
            this.label.LB2BWhseAccount +
            ' ' +
            this.shipToName +
            ' ' +
            this.label.LB2BAccount +
            ' ' +
            +this.shipTo +
            '</p>';
        doc += '<p>' + this.UserName + '</p>';
        doc += '<p>' + this.label.LB2BConfirmAcceptance + '</p>' + '</br>';

        doc += '<table>';
        // Add styles for the table
        doc += '<style>';
        doc += 'table, th, td {';
        doc += '    border: 2px solid black;';
        doc += '    width: 500px;';
        doc += '    border-collapse: collapse;';
        doc += '    text-align: center;';
        doc += '}';
        doc += '</style>';
        // Add all the Table Headers
        doc += '<tr>';
        doc += '<th>' + ' ' + '</th>';
        doc += '<th>' + this.label.LB2BSku + '</th>';
        doc += '<th>' + this.label.LB2BQuantity + '</th>';
        doc += '<th>' + this.label.LB2BCustomerPrice + '</th>';
        doc += '<th>' + this.label.LB2BSBDPrice + '</th>';
        doc += '<th>' + this.label.LB2BTotal + '</th>';
        doc += '</tr>';

        this.demo[0].forEach((record) => {
            if (record) {
                doc += '<tr>';
                doc += '<td>' + record.accept + '</td>';
                doc += '<td>' + record.material + '</td>';
                doc += '<td>' + record.quantity + '</td>';
                doc += '<td>' + record.customerPrice + '</td>';
                doc += '<td>' + record.internalPrice + '</td>';
                doc += '<td>' + record.lineTotal + '</td>';
            } else {
                doc += '<th>' + '</th>';
            }
            doc += '</tr>';
        });
        doc += '</table>';
        this.bodyTemplate = doc;
    }

    sendEmailAfterEvent = (event) => {
        EmailDeliverability()
            .then((result) => {
                console.log('Email settings', result);
                this.emailDeliverabilitySettings = result;
                if (this.emailDeliverabilitySettings == false) {
                    let message = this.label.LB2BEmailDeliverabilityError;
                    console.log('error:', message);
                    this.dispatchEvent(
                        new ShowToastEvent({
                            message: message,
                            variant: 'error',
                            mode: 'dismissable'
                        })
                    );
                }
                console.log('before send email');
            })
            .then(() => {
                this.emailbody();
                sendEmail({
                    body: this.bodyTemplate,
                    subject: this.label.LB2BAcceptReject
                })
                    .then((result) => {
                        console.log('Email sent successfully');
                        localStorage.removeItem('selectedOptions');
                        this.showModal();
                        updateOrderonHoldStatus({Ordernumber: this.OrderNumber});
                    })
                    .catch((error) => {
                        console.log('error in SendEmail:', error);
                    });
            });
        event.preventDefault();
    };
}