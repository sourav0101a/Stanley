import { LightningElement, api, track, wire } from 'lwc';

import getNewCart from '@salesforce/apex/LB2BQuickGetPriceController.getNewCart';
import getPricing from '@salesforce/apex/LB2BQuickGetPriceController.getPricing2';
import addProduct from '@salesforce/apex/LB2BQuickGetPriceController.addProduct';
import deleteSecondaryCart from '@salesforce/apex/LB2BQuickGetPriceController.deleteCart';
import getSapAccountFlags from '@salesforce/apex/LB2BCartController.getSapAccountFlags';
import addToCart from '@salesforce/apex/LB2BQuantitySelectorController.addProductToCart';
import { publish, MessageContext } from 'lightning/messageService';
import cartChanged from '@salesforce/messageChannel/lightning__commerce_cartChanged';
import getImage from '@salesforce/apex/LB2BEnosixHelper.getImages';
import COMMUNITY_ID from '@salesforce/community/Id';
import CURRENCY from '@salesforce/i18n/currency';
import LB2BCheckPriceButton from '@salesforce/label/c.LB2BCheckPriceButton';
import LB2BPriceCheckTitle from '@salesforce/label/c.LB2BPriceCheckTitle';
import LB2BSoldToLabel from '@salesforce/label/c.LB2BSoldToLabel';
import LB2BShipToLabel from '@salesforce/label/c.LB2BShipToLabel';
import LB2BProductSKU from '@salesforce/label/c.LB2BProductSKU';
import LB2BEnterSkuPlaceholder from '@salesforce/label/c.LB2BEnterSkuPlaceholder';
import LB2BQuantity from '@salesforce/label/c.LB2BQuantity';
import LB2BProductName from '@salesforce/label/c.LB2BProductName';
import LB2BUnitPrice from '@salesforce/label/c.LB2BUnitPrice';
import LB2BTotalPrice from '@salesforce/label/c.LB2BTotalPrice';
import LB2BShipping from '@salesforce/label/c.LB2BShipping';
import LB2BPendingAvailability from '@salesforce/label/c.LB2BPendingAvailability';
import LB2BQuantityRoundedFrom from '@salesforce/label/c.LB2BQuantityRoundedFrom';
import LB2BSubstitutedWith from '@salesforce/label/c.LB2BSubstitutedWith';
import LB2BFollowingErrorsOccurred from '@salesforce/label/c.LB2BFollowingErrorsOccurred';
import LB2BQuickPrice from '@salesforce/label/c.LB2BQuickPrice';
import LB2BAddToCart from '@salesforce/label/c.LB2BAddToCart';
import LB2BSuccess from '@salesforce/label/c.LB2BSuccess';
import LB2BPLPAddedToCart from '@salesforce/label/c.LB2BPLPAddedToCart';
import LB2BGenericErrorTitle from '@salesforce/label/c.LB2BGenericErrorTitle';
import LB2BQuickPriceMaxSessionErrorMsg from '@salesforce/label/c.LB2BQuickPriceMaxSessionErrorMsg';
import LB2BQuickPriceMaxSessionErrorMsgClose from '@salesforce/label/c.LB2BQuickPriceMaxSessionErrorMsgClose';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

const DEBUG_MODE = true;

export default class Lb2bQuickGetPrice extends LightningElement {
    // #region Typedefs
    /**
     * @typedef { Object } ShipmentDTO
     *
     * @property {Integer} id
     * @property {Date} estimatedShipDate
     * @property {Number} shipQuantity
     * @property {Boolean} isFreeGood
     * @property {Boolean} isPendingAvailability
     */

    /**
     * @typedef {Object} CartItemDTO
     *
     * @property {String} oldProductName
     * @property {String} productName
     * @property {String} oldProductSku
     * @property {String} productSku
     * @property {Number} oldUnitPrice
     * @property {Number} unitPrice
     * @property {Number} oldQuantity
     * @property {Number} quantity
     * @property {Number} oldExtendedPrice
     * @property {Number} extendedPrice
     * @property {Boolean} hasBomOrFreeGoods
     * @property {Boolean} hasSubstituteProducts
     * @property {Boolean} hasRoundedQuantity
     * @property {Array<CartItemDTO>} sublineList
     * @property {Array<ShipmentDTO>} shipmentList
     */

    /**
     * @typedef {Object} OrderSimulateWrapper
     *
     * @property {String} cartId
     * @property {String} status
     * @property {Array<String>} sapErrors
     * @property {Boolean} hasErrors
     * @property {Array<CartItemDTO>} cartItems
     */
    // #endregion

    @api
    effectiveAccountId;

    @wire(MessageContext)
    messageContext;

    @track
    cartId;

    productSku;
    quantity;

    isOpen = false;
    isLoading = false;
    isAdding = false;
    isCalculating = false;
    isMaxcart; 

    currency;
    communityId;

    labels = {
        LB2BAddToCart,
        LB2BCheckPriceButton,
        LB2BEnterSkuPlaceholder,
        LB2BFollowingErrorsOccurred,
        LB2BPendingAvailability,
        LB2BPriceCheckTitle,
        LB2BProductName,
        LB2BProductSKU,
        LB2BQuantity,
        LB2BQuantityRoundedFrom,
        LB2BQuickPrice,
        LB2BShipToLabel,
        LB2BShipping,
        LB2BSoldToLabel,
        LB2BSubstitutedWith,
        LB2BTotalPrice,
        LB2BUnitPrice,
        LB2BSuccess,
        LB2BPLPAddedToCart,
        LB2BGenericErrorTitle,
        LB2BQuickPriceMaxSessionErrorMsg,
        LB2BQuickPriceMaxSessionErrorMsgClose
    };

    /** @type {OrderSimulateWrapper} */
    pricingResult;

    connectedCallback() {
        this.currency = CURRENCY;
        this.communityId = COMMUNITY_ID;
        // When we close browser page or single tab or reload  
        window.addEventListener('beforeunload', (event) => {this.handleBrowserclose(event)});
    }

    // handle browser close or single tab close or reload the page
    handleBrowserclose(event){
        // delete secondary cart 
        deleteSecondaryCart({ cartId: this.cartId }).catch((error) => {
            //console.log('No cart to delete');
        });
    }

    handlepopupclose(event){
        this.isMaxcart = false;
    }

    handleToggleOpenClick(event) {
        this.pricingResult = null;
        this.isOpen = !this.isOpen;
        this.isMaxcart = false;

        if (this.isOpen) {
            getNewCart({ accountId: this.effectiveAccountId, communityId: this.communityId })
                .then((result) => {
                    if (DEBUG_MODE) {
                        console.log('Cart:', result);
                    }
                    this.cartId = result;
                })
                .catch((err) => {
                    console.error('Error getting a new cart', err);
                    this.isOpen = false;
                    this.isMaxcart = true;

                });
        } else {
            if (this.cartId) {
                deleteSecondaryCart({ cartId: this.cartId }).catch((error) => {
                    // console.log('No cart to delete');
                });
           }
        }
    }

    disconnectedCallback() {
        if (this.cartId) {
            deleteSecondaryCart({ cartId: this.cartId }).catch((error) => {
                // console.log('No cart to delete');
            });
        }
        window.removeEventListener('beforeunload', (event) => {this.handleBrowserclose(event)});
    }

    handleGetPriceClick(event) {
        this.pricingResult = null;

        if (this.productSku && this.productSku != '' && this.quantity && this.quantity > 0) {
            this.isLoading = true;

            this.isAdding = true;
            addProduct({
                productSku: this.productSku,
                quantity: parseInt(this.quantity),
                communityId: this.communityId,
                effectiveAccountId: this.effectiveAccountId,
                cartId: this.cartId
            })
                .then((res) => {
                    this.isAdding = false;
                    this.isCalculating = true;

                    getPricing({ cartId: this.cartId })
                        .then((res2) => {
                            this.isCalculating = false;

                            /** @type {OrderSimulateWrapper} */
                            const output = res2;
                            if (DEBUG_MODE) {
                                console.log(res2);
                            }

                            this.pricingResult = {
                                hasErrors: output.hasError,
                                sapErrors: output.sapErrors
                            };

                            if (res2.status && res2.status.includes('ERROR')) {
                                if (!(res2.sapErrors && res2.sapErrors.length > 0)) {
                                    this.pricingResult.sapErrors = ['An unknown error occurred'];
                                    this.pricingResult.hasErrors = true;
                                }
                            } else {
                                let isFirst = true;
                                if (output.cartItems) {
                                    output.cartItems.forEach((x) => {
                                        if (isFirst) {
                                            isFirst = false;
                                            this.pricingResult.item = x;
                                        }
                                    });
                                }
                            }

                            console.log('Result:', this.pricingResult);

                            this.isLoading = false;
                        })
                        .catch((err) => {
                            console.error('Error getting pricing:', err);
                            this.isLoading = false;
                        });
                })
                .catch((err) => {
                    console.error(err);
                    let message = 'Invalid quantity or SKU.';

                    if (err.body.message.includes("You can't view")) {
                        message = 'You cannot check the price of this SKU.';
                    } else if (err.body.message.includes('No products found')) {
                        message = 'Invalid SKU';
                    } else if (err.body.message.includes('Resource')) {
                        message = 'Internal server error, please refresh and try again.';
                    } else if (err.body.message.includes('minimum')) {
                        let splitMessage = err.body.message.split(': ');
                        if (splitMessage.length > 1) {
                            message = splitMessage[1];
                        } else {
                            message = err.body.message;
                        }
                    }

                    this.pricingResult = {
                        hasErrors: true,
                        sapErrors: [message]
                    };

                    this.isLoading = false;
                });
        } else {
            this.pricingResult = {
                hasErrors: true,
                sapErrors: ['Please enter both a product SKU and quantity']
            };
        }
    }

    handleProductChange(event) {
        this.productSku = event.target.value.trim();
        this.pricingResult = null;
    }

    handleQuantityChange(event) {
        this.quantity = event.target.value;
        this.pricingResult = null;
    }

    handleSoldToSelected(event) {
        const sapNumber = event.detail;

        if (sapNumber) {
            getSapAccountFlags({ sapAccountId: sapNumber })
                .then((res) => {
                    if (res.length == 1 && res[0].Indirect_Sold_To__c) {
                        this.template.querySelector('.ship-to-container').style.display = 'block';
                    } else {
                        this.template.querySelector('.ship-to-container').style.display = 'none';
                    }
                })
                .catch((err) => {
                    console.error(err);
                });
        } else {
            this.template.querySelector('.ship-to-container').style.display = 'none';
        }
    }

    get showAddToCart() {
        if (this.pricingResult) {
            return !this.pricingResult.hasErrors;
        } else {
            return false;
        }
    }

    handleAddToCart() {
        addToCart({
            productId: this.pricingResult.item.product2Id,
            quantity: this.pricingResult.item.quantity,
            communityId: this.communityId,
            accountId: this.effectiveAccountId
        })
            .then((result) => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: this.labels.LB2BSuccess,
                        message: this.labels.LB2BPLPAddedToCart,
                        variant: 'success'
                    })
                );

                publish(this.messageContext, cartChanged);
            })
            .catch((error) => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: this.labels.LB2BGenericErrorTitle,
                        message: err,
                        variant: 'error'
                    })
                );
                console.error(error);
            });
    }
}