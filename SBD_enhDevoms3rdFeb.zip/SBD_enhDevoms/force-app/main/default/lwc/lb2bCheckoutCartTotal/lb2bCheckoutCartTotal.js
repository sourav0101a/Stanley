/**
 * lb2bCheckoutCartTotal is used in checkout page to display the Account details, Shipping address
 * and total price of product.
 */

import { api, LightningElement, track, wire } from 'lwc';
import LANG from '@salesforce/i18n/lang';
import getCartItems from '@salesforce/apex/LB2BCartController.getCartItems';
import communityId from '@salesforce/community/Id';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import { getLabelForOriginalPrice } from 'c/lb2bCartUtils';
import USER_ID from '@salesforce/user/Id';
import getSapTotal from '@salesforce/apex/LB2BCartController.getSapTotal';
import SAP_Customer_Number from '@salesforce/schema/User.Account.SAP_Customer_Number__c';
import LB2BAccount from '@salesforce/label/c.LB2BAccount';
import LB2BShip_To from '@salesforce/label/c.LB2BShip_To';
import LB2BSold_To from '@salesforce/label/c.LB2BSold_To';
import LB2BOrderSummary from '@salesforce/label/c.LB2BOrderSummary';
import LB2BBrand from '@salesforce/label/c.LB2BBrand';
import LB2BSubtotal from '@salesforce/label/c.LB2BSubtotal';
import LB2BFreight from '@salesforce/label/c.LB2BFreight';
import LB2BResidentialFee from '@salesforce/label/c.LB2BResidentialFee';
import LB2BLiftFee from '@salesforce/label/c.LB2BLiftFee';
import LB2BTotal from '@salesforce/label/c.LB2BTotal';
import LB2BMultipleLocation from '@salesforce/label/c.LB2BMultipleLocation'; 
import LB2BSavings from '@salesforce/label/c.LB2BSavings';
import LB2BContinueOrderReview from '@salesforce/label/c.LB2BContinueOrderReview';
import LB2BEditCart from '@salesforce/label/c.LB2BEditCart';
import LB2BLiftHelpText from '@salesforce/label/c.LB2BLiftHelpText';
import LB2BResidentHelpText from '@salesforce/label/c.LB2BResidentHelpText';
import LB2BRequiredFieldError from '@salesforce/label/c.LB2BRequiredFieldError';
import LB2BZipCodeError from '@salesforce/label/c.LB2BZipCodeError';
import LB2BError from '@salesforce/label/c.LB2BError';
import LB2BCheckout from '@salesforce/label/c.LB2BCheckout';
import { registerListener } from 'c/lb2bPubSub';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getData from '@salesforce/apex/LB2BCallEnosix.getData';
import getSapAccountFlags from '@salesforce/apex/LB2BCartController.getSapAccountFlags';
import CURRENCY_CODE from '@salesforce/i18n/currency';
import {EditCartFromCheckout} from 'c/lb2bDataLayer';
import { fireEvent } from 'c/lb2bPubSub';

export default class lb2bCheckoutCartTotal extends NavigationMixin(LightningElement) {
    @track brand;
    @track error;
    @track subTotal;
    @track freight;
    @track residentialFreightFee;
    @track liftGateFee;
    @track total;
    @track savings;
    @api recordId;
    @api effectiveAccountId;
    @api TotalAmount;
    @api RecordId1;
    @api cartId;
    @api SoldtoAccountname;
    @api accountName;
    @api multipleShipTo;
    @api ShippingStreet;
    @api ShippingCity;
    @api ShippingState;
    @api ShippingCountry;
    @api ShippingPostalCode;

    currencyCode = CURRENCY_CODE;
    @track checked = false;
    @api validateFields;
    @api doShowFreightFields = false;
    isLoading = false;
    // @api isPattern;

    @wire(CurrentPageReference)
    pageRef;

    pageParam = null;
    sortParam = 'CreatedDateDesc';
    @api displayTotal;
    @api isDisabled = false;

    label = {
        LB2BShip_To,
        LB2BSold_To,
        LB2BAccount,
        LB2BOrderSummary,
        LB2BBrand,
        LB2BSubtotal,
        LB2BFreight,
        LB2BResidentialFee,
        LB2BLiftFee,
        LB2BTotal,
        LB2BSavings,
        LB2BContinueOrderReview,
        LB2BEditCart,
        LB2BLiftHelpText,
        LB2BResidentHelpText,
        LB2BRequiredFieldError,
        LB2BZipCodeError,
        LB2BError,
        LB2BCheckout
    };

    _connectedResolver;
    _canResolveUrls = new Promise((resolved) => {
        this._connectedResolver = resolved;
    });

    navigateToCart(event) {
        // window.history.back();
        EditCartFromCheckout('edit_cart');
        let url = window.location.href;
        // let newUrl = url.replace(/checkout/, 'cart');
        let newUrl = url.replace(/order-review/, 'cart');
        //this.showSpinner = false;
        this.navigateToWebPage(newUrl);
    }

    navigateToOrderReview(event) {
        let url = window.location.href.split('/s/');
        // let newUrl = url[0] + '/s/order-review';
        let newUrl = url[0] + '/s/checkout';
        // console.log("cartId",this.recordId);
        //this.showSpinner = false;
        localStorage.setItem('cartId', this.recordId);

        //To validate DropShip Address Mandatory Fields
        localStorage.setItem('checkbox', this.checked);
        console.log('Is Checked:', this.checked);
        console.log('this.validateFields:', this.validateFields);
        if (this.checked == false) {
            this.navigateToWebPage(newUrl);
        }

        if (this.checked == true && this.validateFields == undefined) {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: this.label.LB2BError,
                    message: this.label.LB2BRequiredFieldError,
                    variant: 'error'
                })
            );
        }
        // else if((this.checked == true) && (this.validateFields != undefined) && ((this.isPattern == false))){
        //         this.dispatchEvent(
        //             new ShowToastEvent({
        //               title: 'Error',
        //               message: this.label.LB2BZipCodeError,
        //               variant: 'error'
        //             })
        //         )
        //     }
        else {
            this.navigateToWebPage(newUrl);
        }
    }
    navigateToWebPage(url) {
        console.log(url);
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url
            }
        });
    }

    connectedCallback() {
        this._connectedResolver();
        // this.updateCartItems();
        registerListener('_callCartTotal', this.callUpdateCartItems, this);
        registerListener('checkbox', this.validateCheckbox, this);
        registerListener('dropship', this.validateDropShip, this);
        registerListener('_deleteCartItem', this.handleEvent, this);
        registerListener('brandName', this.brandName, this);
    //  registerListener('pattern',this.checkPattern,this );
    }

    callUpdateCartItems() {
        console.log('_call fire event ');
        this.updateCartItems();
    }

    // checkPattern(input){
    //     console.log("---INSIDE CheckPattern---",input);
    //     this.isPattern = (/^[0-9]+$/).test(input);
    //     console.log("Pattern Matched:",this.isPattern);
    // }

    handleEvent() {
        console.log('_deletecartItem event', this.recordId);
        getData({ CartId: this.recordId })
            .then((result) => {
                this.updateCartItems();
            })
            .catch((error) => {
                console.log('error', error);
            });
    }

    get resolvedEffectiveAccountId() {
        const effectiveAccountId = this.effectiveAccountId || '';
        let resolved = null;
        if (effectiveAccountId.length > 0 && effectiveAccountId !== '000000000000000') {
            resolved = effectiveAccountId;
        }
        return resolved;
    }

    updateCartItems() {
    //    this.isLoading = false;

        getSapTotal({
            webcartId: this.recordId
        }).then((result) => {
            console.log('lb2b total: ', result);           
            this.displayTotal = result[0];

            fireEvent(this.pageRef, 'OrderSummaryToPdf', this.displayTotal);

            this.ensxb2b__sap_BillTo_PartnerNumber = result[0].ensxb2b__sap_BillTo_PartnerNumber__c;
            this.SoldtoAccountname = result[0].Sold_To_SAP_Account__r.Name;
            if(result[0].Ship_To_SAP_Account__r!= undefined) {
            this.accountName = result[0].Ship_To_SAP_Account__r.Name;
            this.ShippingStreet = result[0].Ship_To_SAP_Account__r.Street__c;
            this.ShippingCity = result[0].Ship_To_SAP_Account__r.City__c;
            this.ShippingState = result[0].Ship_To_SAP_Account__r.State__c;
            // this.ShippingState = result[0].Ship_To_SAP_Account__r.City__c ;
            this.ShippingPostalCode = result[0].Ship_To_SAP_Account__r.Postal_Code__c;
            this.ShippingCountry = result[0].Ship_To_SAP_Account__r.Country__c
            } else {
                this.multipleShipTo = LB2BMultipleLocation;
            }
            // this.brand= result[0].Search_Term_2__c;

            if (result[0].LB2B_SubTotal__c != undefined || result[0].LB2B_SubTotal__c != null) {
                this.subTotal = result[0].LB2B_SubTotal__c;
            } else {
                this.subTotal = '0.00';
            }

            if (result[0].Freight__c == null) {
                this.freight = '0.00';
            } else {
                this.freight = result[0].Freight__c;
                console.log('freight', this.freight);
            }

            if (result[0].Residential_Freight_Fee__c == null) {
                this.residentialFreightFee = '0.00';
            } else {
                this.residentialFreightFee = result[0].Residential_Freight_Fee__c;
            }

            if (result[0].Lift_Gate_Fee__c == null) {
                this.liftGateFee = '0.00';
            } else {
                this.liftGateFee = result[0].Lift_Gate_Fee__c;
            }

            if (this.displayTotal.UniqueProductCount == 0) {
                this.isDisabled = true;
            }

            this.total = result[0].LB2B_Total__c;
            this.savings = result[0].LB2B_Savings__c;

            this.isLoading = true;

            console.log('frieght', this.frieght);
            // this.savings= (result[0].GrandTotalAmount)-(result[0].LB2B_SubTotal__c);
            // console.log('savings',this.savings);

            getSapAccountFlags({ sapAccountId: result[0].Sold_To_SAP_Account__c })
                .then((accountResult) => {
                    if (accountResult.length == 0) {
                        this.doShowFreightFields = true;
                    } else {
                        if (accountResult[0].CurrencyIsoCode == 'USD') {
                            this.doShowFreightFields = true;
                        } else {
                            this.doShowFreightFields = false;
                        }
                    }
                })
                .catch((err) => {
                    console.log('SAP Account Flags Error:', err);
                });
        });
    }

    @wire(getRecord, { recordId: USER_ID, fields: [SAP_Customer_Number] })
    user;

    get sapAccountNumber() {
        return getFieldValue(this.user.data, SAP_Customer_Number);
    }

    brandName(val) {
        console.log('Search_Term_2 Value:', val);
        this.brand = val[0].Search_Term_2__c;
    }

    validateCheckbox(val) {
        console.log(' fired Checkbox event:', val);
        this.checked = val;
    }

    validateDropShip(dropAddress) {
        console.log('Validate Fields:', dropAddress);

        if (
            dropAddress.fields.SAP_ShipTo_Override_Street__c == undefined ||
            dropAddress.fields.SAP_ShipTo_Override_City__c == undefined ||
            dropAddress.fields.SAP_ShipTo_Override_Region__c == undefined ||
            dropAddress.fields.SAP_ShipTo_Override_PostalCode__c == undefined ||
            dropAddress.fields.SAP_ShipTo_Override_Street__c == '' ||
            dropAddress.fields.SAP_ShipTo_Override_City__c == '' ||
            dropAddress.fields.SAP_ShipTo_Override_Region__c == '' ||
            dropAddress.fields.SAP_ShipTo_Override_PostalCode__c == ''
        ) {
            console.log('INSIDE If ---- Except Error');
            this.validateFields = undefined;
        } else {
            console.log('INSIDE ELSE ----- NO ERROR');
            this.validateFields = dropAddress;
        }
    }
}