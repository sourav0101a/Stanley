import { LightningElement, api, wire } from 'lwc';
import LB2BUpcCode from '@salesforce/label/c.LB2BUpcCode';
import { NavigationMixin } from 'lightning/navigation';
import { HtmlHelper } from 'c/lb2bUtil';
import LOCALE from '@salesforce/i18n/locale';
import pdpStock from '@salesforce/apex/LB2BSearchPLPController.pdpStock';
// import { registerListener } from 'c/lb2bPubSub';
// import { CurrentPageReference } from 'lightning/navigation';
import { productView } from 'c/lb2bDataLayer';

export default class Lb2bProductDetailsDisplay extends NavigationMixin(LightningElement) {



    label = {
        LB2BUpcCode
    };
    /**
   * A product field.
   * @typedef {object} CustomField
   *
   * @property {string} name
   *  The name of the custom field.
   *
   * @property {string} value
   *  The value of the custom field.
   */

    /**
     * An iterable Field for display.
     * @typedef {CustomField} IterableField
     *
     * @property {number} id
     *  A unique identifier for the field.
     */
    @api brand;
    @api description;
    @api upc;
    // @api stockmx;
    // @api stockca;
    // @api stockus;
    @api _stock;
    @api stock;
    @api stockcolor;
    @api features;
    @api currencycode;
    @api productname;
    @api productsku;
    @api recordId;
    isMexico = false;
    isCanada = false;
    isUsa = false;

    /**
     * Gets or sets which custom fields should be displayed (if supplied).
     *
     * @type {CustomField[]}
     */
    @api
    customFields;

    // @wire(CurrentPageReference) pageRef;
    /**
     * Gets the iterable fields.
     *
     * @returns {IterableField[]}
     *  The ordered sequence of fields for display.
     *
     * @private
     */
    get _displayableFields() {
        // Enhance the fields with a synthetic ID for iteration.
        return (this.customFields || []).map((field, index) => ({
            ...field,
            id: index
        }));
    }

    get _features(){
        const val=  this.features;
        // this.features=val;
        return val.split("||").slice(0, 10);
     }

    connectedCallback() {
        this.description = HtmlHelper.parseHtml(this.description);

        // registerListener('layoutdata22', this.handleLayoutdata, this);

        // pdpStock({
        //     pdodId: this.recordId
        // }).then((result) => {
        //     console.log('result 2>>>',result);
        // })
        // .catch((error) =>{
        //     console.log('error of pdpStock >>>: ', error)
        // });
        // if (LOCALE === 'es-MX') {
        //     this.isMexico = true;
        //     this.getstockAvailabilityColor(this.stockmx);
        // } else if (LOCALE === 'fr-CA') {
        //     this.isCanada = true;
        //     this.getstockAvailabilityColor(this.stockca);
        // } else if (LOCALE === 'en-US') {
        //     this.isUsa = true;
        //     this.getstockAvailabilityColor(this.stockus);
        // }

        productView('view_item',this.currencycode,this.productname,this.brand,this.productsku,null,this.upc,this.stockMx,this.stockCa,this.stockUs,null);
    }

    set stock(data){
        this._stock = data;
        this.getstockAvailabilityColor(this._stock);
    }
    get stock(){
        return this._stock;
    }
    getstockAvailabilityColor(data){
        if(data === 'In Stock'){
            this.stockAvailabilityColor = 'item-in-stock flex-right-or-left'
        }
        else if (data === 'Out of Stock'){
            this.stockAvailabilityColor = 'item-out-stock flex-right-or-left'
        }
        else{
            this.stockAvailabilityColor = 'item-low-stock flex-right-or-left'
        }
    }

    // handleLayoutdata(data){
    //     alert('inside handlelayout >>> ',data);
    //     console.log('data >>>',data);
    // }

}