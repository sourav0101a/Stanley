import { LightningElement,api,track,wire } from 'lwc';
import getUserList from '@salesforce/apex/LB2BUserInfo.getUserList';
// import getUserSapAccList from '@salesforce/apex/LB2BUserInfo.getUserSapAccList';
import executeBatchJob from '@salesforce/apex/LB2BUserInfo.executeBatchJob';
import getUpdatedSapCount from '@salesforce/apex/LB2BUserInfo.getUpdatedSapCountlist';
import getUserSapAccInfo from '@salesforce/apex/LB2BUserInfo.getUserSapAccInfo';
import { NavigationMixin,CurrentPageReference } from 'lightning/navigation';
import { deleteRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

const actions = [
    { label: 'View/Edit Assignments', name: 'view_edit' },
    { label: 'Go to User Details', name: 'show_details' },
];

const detailsActions = [
    { label: 'Edit', name: 'edit' },
    { label: 'Delete', name: 'delete' },
];

export default class Lb2bUserInfo extends NavigationMixin(LightningElement) {

 @api inactiveUserList;
 @api activeUserList;
 @api searchArray;
 @api userSapAccList;
 @track soldToShipToList;
 @track dataTableList;
 @track dataTableListColumns;
 @track value = 'Active';
 @track isSapAccountCount = false;
 @track isLoader = true;
 @track loadModal;
 @track dataTableHeader = 'Active users info';
 @track sortBy;
 @track sortDirection;
 @track isModalOpen = false;
 @track isCreateEdit = false; 
 record = {};
 @api createEditObj = {};
 sapAccountInfo;
 @track isModified;
 @track customClass = 'default-class';

@wire(CurrentPageReference)
pageRef;

 inactiveUserListColumns = [
    { label: 'User Id', fieldName: 'Id', sortable: "true" },
    { label: 'Name', fieldName: 'Name', sortable: "true"},
    { label: 'User Name', fieldName: 'Username', sortable: "true" },
    { label: 'Email Id', fieldName: 'Email', sortable: "true"},
    { label: 'Account Name', fieldName: 'accountName', sortable: "true" },
    { label: 'Profile Name', fieldName: 'profileName', sortable: "true" },
    { label: 'Last Login Date', fieldName: 'lastLoginDate', sortable: "true" }
];

userSapAccListColumns = [
    { label: 'User Id', fieldName: 'Id' },
   // { label: 'User Id', fieldName: 'User__c' },
    { label: 'Name', fieldName: 'Name', sortable: "true"},
    { label: 'User Name', fieldName: 'Username', sortable: "true" },
    { label: 'Email Id', fieldName: 'Email', sortable: "true"},
    { label: 'Unique SoldTo Count', fieldName: 'Sold_To_Count__c', sortable: "true" },
    { label: 'Unique ShipTo Count', fieldName: 'Ship_To_Count__c', sortable: "true" },
    //{ label: 'Unique ShipTo Count', fieldName: 'expr0', sortable: "true"},
    //{ label: 'Unique SoldTo Count', fieldName: 'expr1', sortable: "true"},
    {
        type: 'action',
        typeAttributes: { rowActions: actions },
    },
];

soldToShipToAccColumns = [
    { label: 'Active', fieldName: 'Is_Active__c' },
    { label: 'Sold To Number', fieldName: 'SoldToSapAccNum', sortable: "true"},
    { label: 'Sold To Address', fieldName: 'SoldToSapAccName', sortable: "true"},
    { label: 'Ship To Number', fieldName: 'ShipToSapAccNum', sortable: "true"},
    { label: 'Ship To Address', fieldName: 'ShipToSapAccName', sortable: "true" },   
    { label: 'Search Term 2', fieldName: 'searchTerm2', sortable: "true"},
    {
        type: 'action',
        typeAttributes: { rowActions: detailsActions },
    },
];

  
columnHeader = [
    'User Id',
    'Name',
    'User Name',
    'Email Id',
    'Account Name',
    'Profile Name',
    'Last Login Date'
];
sapAccountscolumnHeader = [
    'UserId',
    'Name',
    'User Name',
    'Email Id',
    'Unique ShipTo Count',
    'Unique SoldTo Count'
];

    connectedCallback(){
        this.getUserList('Active');
        this.getUserList('InActive');
      //  this.getUserSapAccList();
      this.executeBatchJob();
    }

    
    executeBatchJob(){
        executeBatchJob({})
         .then(result => {
           this.getUpdatedSapCountList();
            console.log('result of batch job ', result); 
         })
         .catch(error => {
            console.log('batch job error ', error)
         })   
    }

    getUpdatedSapCountList(){
        getUpdatedSapCount({})
         .then(result => {
            let tempRecords = result.map( row => {
                return { ...row, 
                    Sold_To_Count__c:row.Sold_To_Count__c !=undefined ? row.Sold_To_Count__c:0, 
                    Ship_To_Count__c: row.Ship_To_Count__c !=undefined ? row.Ship_To_Count__c:0}
            })
            this.userSapAccList = tempRecords;
            console.log('result of batch apex class ', result); 
         })
         .catch(error => {
            console.log('batch apex error ', error)
         })   
    }

    getUserList(value){
        getUserList({
            value : value
        })
         .then(result => {
            let tempRecords = result.map( row => {
                return { ...row, 
                    accountName:row.Account !=undefined ? row.Account.Name:'', 
                    profileName: row.Profile.Name,
                    lastLoginDate:row.LastLoginDate !=undefined ? row.LastLoginDate.replace(/T/, ' ').replace(/\..+/, ''):''}
            })
        
            if(value == 'Active'){
                this.activeUserList = tempRecords;
                this.dataTableList = this.activeUserList;
                this.searchArray = this.activeUserList;
                this.isLoader = false;
            }
            else{
                this.inActiveUserList = tempRecords;
            }          
            this.dataTableListColumns = this.inactiveUserListColumns;
            console.log('result of get user list ', tempRecords);  
         })
         .catch(error => {
            console.log('Get user list error ', error)
         })   
    }

    // getUserSapAccList(){
    //     getUserSapAccList({})
    //      .then(result => {
    //         this.userSapAccList = result;
    //         console.log('result of get user erp list ', result); 
            
    //         //To update the count after creating/deleting sap account
    //         if(this.isModified){
    //             this.handleUserSapAccInfo();
    //         }
    //      })
    //      .catch(error => {
    //         console.log('Get user erp list error ', error)
    //      })   
    // }

    getUserSapAccInfo(Id){
        getUserSapAccInfo({
            userId:Id
        })
         .then(result => {
            this.sapAccountInfo = result;
            let tempRecords = result.map( row => {
                if(row != undefined){
                    return { ...row, 
                        ShipToSapAccName: row.Ship_To_SAP_Account__r != undefined ? row.Ship_To_SAP_Account__r.Name : '',
                        SoldToSapAccName: row.Sold_To_SAP_Account__r != undefined ? row.Sold_To_SAP_Account__r.Name : '',
                        ShipToSapAccNum: row.Ship_To_SAP_Account__r != undefined ? row.Ship_To_SAP_Account__r.Clean_SAP_Number__c : '',
                        SoldToSapAccNum:  row.Sold_To_SAP_Account__r != undefined ? row.Sold_To_SAP_Account__r.Clean_SAP_Number__c : '',
                        searchTerm2: row.Sold_To_SAP_Account__r != undefined ? row.Sold_To_SAP_Account__r.Search_Term_2__c : '' };
                }             
            })
            this.soldToShipToList = tempRecords;
            this.searchArray = tempRecords;
            this.isLoader = false;
            this.loadModal = false;
            this.isModalOpen = true; 
         })
         .catch(error => {
            console.log('SoldTo ShipTo list error ', error)
         })   
    }
    
    handleUserSapAccInfo(){
        this.customClass = 'click-user-sap';
        this.dataTableList = this.userSapAccList;
        this.dataTableListColumns = this.userSapAccListColumns;
        this.dataTableHeader = 'User SAP Accounts Count'; 
        this.searchArray = this.userSapAccList;
        this.isSapAccountCount = true;
         this.value = '';
    }

    doSorting(event) {
        this.sortBy = event.detail.fieldName;
        this.sortDirection = event.detail.sortDirection;
        this.sortData(this.sortBy, this.sortDirection);
    }

    sortData(fieldname, direction) {
        let parseData = this.isModalOpen ? JSON.parse(JSON.stringify(this.soldToShipToList))
                                         :JSON.parse(JSON.stringify(this.dataTableList));
        // Return the value stored in the field
        let keyValue = (a) => {
            return a[fieldname];
        };
        // cheking reverse direction
        let isReverse = direction === 'asc' ? 1: -1;
        // sorting data
        parseData.sort((x, y) => {
            x = keyValue(x) ? keyValue(x) : ''; // handling null values
            y = keyValue(y) ? keyValue(y) : '';
            // sorting values based on direction
            return isReverse * ((x > y) - (y > x));
        });
        this.isModalOpen ? this.soldToShipToList = parseData :  this.dataTableList = parseData;
    }  

    value ='Active';
    get options() {
        return [
            { label: 'Active Users', value: 'Active' },
            { label: 'Inactive Users', value: 'Inactive' } 
        ];
    }

    handleDropDownChange(event) {
        this.customClass = 'default-class';
        this.value = event.detail.value;
        this.isSapAccountCount = false;
        this.dataTableListColumns = this.inactiveUserListColumns;
        if(event.detail.value == 'Active'){
            this.dataTableList = this.activeUserList;
            this.searchArray = this.activeUserList;
            this.dataTableHeader = 'Active Users Info';
        }
        else{
            this.dataTableList = this.inActiveUserList;
            this.searchArray = this.inActiveUserList;
            this.dataTableHeader = 'Inactive Users Info';
        }
    }

    exportToExcel() {
        if (this.isSapAccountCount){
            this.userSapAccountCount();
        }else{
            this.userList();
        }
     }

     userList(){
        let doc = '<table>';
        doc += '<style>';
        doc += 'table, th, td {';
        doc += '    border: 1px solid black;';
        doc += '    border-collapse: collapse;';
        doc += '}';
        doc += '</style>';
        // Adding all the Table Headers
        doc += '<tr>';
        this.columnHeader.forEach((element) => {
           doc += '<th>' + element + '</th>';
        });
        doc += '</tr>';
        // Adding the data rows
        this.dataTableList.forEach((record) => {   
            if (record) {
               doc += '<tr>';
               doc += '<th>' + record.Id + '</th>';
               doc += '<th>' + record.Name + '</th>';
               doc += '<th>' + record.Username + '</th>';
               doc += '<th>' + record.Email + '</th>';
               doc += '<th>' + record.accountName + '</th>';
               doc += '<th>' + record.profileName + '</th>';
               doc += '<th>' + record.lastLoginDate + '</th>';
               doc += '</tr>';
            } else {
               doc += '<th>' + '</th>';
            }
         });
         doc += '</table>';
         var element = 'data:application/vnd.ms-excel,' + encodeURIComponent(doc);
         let downloadElement = document.createElement('a');
         downloadElement.href = element;
         downloadElement.target = '_self';
         if (this.value == 'Active'){
            downloadElement.download = 'Active Users Details.xls';
         }
         else {
            downloadElement.download = 'Inactive Users Account Details.xls';
         }
         
         document.body.appendChild(downloadElement);
         downloadElement.click();
     }

     userSapAccountCount(){
        let doc = '<table>';
        doc += '<style>';
        doc += 'table, th, td {';
        doc += '    border: 1px solid black;';
        doc += '    border-collapse: collapse;';
        doc += '}';
        doc += '</style>';
        // Adding all the Table Headers
        doc += '<tr>';
        this.sapAccountscolumnHeader.forEach((element) => {
           doc += '<th>' + element + '</th>';
        });
        doc += '</tr>';
        // Adding the data rows
        this.userSapAccList.forEach((record) => {
            if (record) {
               doc += '<tr>';
               doc += '<th>' + record.Id + '</th>';
               doc += '<th>' + record.Name + '</th>';
               doc += '<th>' + record.Username + '</th>';
               doc += '<th>' + record.Email + '</th>';
               doc += '<th>' + record.Sold_To_Count__c + '</th>';
               doc += '<th>' + record.Ship_To_Count__c + '</th>';
               doc += '</tr>';
            } else {
               doc += '<th>' + '</th>';
            }
         });
         doc += '</table>';
         var element = 'data:application/vnd.ms-excel,' + encodeURIComponent(doc);
         let downloadElement = document.createElement('a');
         downloadElement.href = element;
         downloadElement.target = '_self';
         downloadElement.download = 'User SAP Accounts Count.xls';
         document.body.appendChild(downloadElement);
         downloadElement.click();

     }

    handleSearch( event ) {
        const searchKey = event.target.value.toLowerCase();
        if ( searchKey ) {
            this.isModalOpen ? this.soldToShipToList = this.searchArray :  this.dataTableList = this.searchArray;

            if ( this.searchArray ) {
                let recs = [];        
                for ( let rec of this.searchArray ) {
                    let valuesArray = Object.values( rec );
 
                    for ( let val of valuesArray ) {
                        let strVal = String( val );
                        
                        if ( strVal ) {
                            if ( strVal.toLowerCase().includes( searchKey ) ) {
                                recs.push( rec );
                                break;                    
                            }
                        }
                    }                    
                }
                this.isModalOpen ? this.soldToShipToList = recs :  this.dataTableList = recs;
             }
        }  else {
            this.isModalOpen ? this.soldToShipToList = this.searchArray :  this.dataTableList = this.searchArray;           
        }        
    }

    handleRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        switch (actionName) {
            case 'view_edit':
                this.viewEditDetails(row);
                break;
            case 'edit':
                this.editRowDetails(row);
                break;
            case 'delete':
                this.loadModal = true;
                this.deleteRow(row);
                break;
            case 'show_details':
                this.showRowDetails(row);
                break;
            default:
        }
    }

    viewEditDetails(row) {
        this.isLoader = true;
        this.record = row;
        this.getUserSapAccInfo(row.Id);       
    }
   
    showRowDetails(row){
       this[NavigationMixin.Navigate]({
        type: 'standard__recordPage',
        attributes: {
            objectApiName: 'User',
            recordId: row.Id,
            actionName: 'view'
        }
    });
}

editRowDetails(row){
    this.createEditObj ={
        createEditModal : true,
        record : row
    }
    this.isCreateEdit = true;
    this.isModalOpen = false;
}

deleteRow(row) {  
    deleteRecord(row.Id)
        .then(() => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Record deleted',
                    variant: 'success'
                })
            );
            this.getUserSapAccInfo(this.record.Id);
            this.isModified = true;
        })
        .catch(error => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error deleting record',
                    message: error.body.message,
                    variant: 'error'
                })
            );
        });
}

createNewAssignment(){
    this.createEditObj ={
        createEditModal : true,
        record : {
            Id:undefined,
            User__c:this.record.Id,
            Sold_To_SAP_Account__c:undefined,
            Ship_To_SAP_Account__c:undefined
        }
    }
    this.isCreateEdit = true;
    this.isModalOpen = false;
}

    closeModal() {
        this.isModalOpen = false;

        //To update the count after creating/updating/deleting sap account
        if(this.isModified){
           // this.getUserSapAccList();
           this.executeBatchJob();
        }  
    }

    hanldeCloseModal(event) {
        this.isModified = event.detail;
        this.isCreateEdit = false;
        this.isModalOpen = true;
       if(this.isModified){
            this.getUserSapAccInfo(this.record.Id);   
        }     
      }
}