import getBase64FromImageUrl from '@salesforce/apex/LB2BRestApiController.getBase64';


export function getCompareProductsPdf(compareProducts,sbdLogo) {

  // function getBase64Image(img) {
  //   var canvas = document.createElement("canvas");
  //   canvas.width = img.width;
  //   canvas.height = img.height;
  //   var ctx = canvas.getContext("2d");
  //   ctx.drawImage(img, 0, 0);
  //   var dataURL = canvas.toDataURL("image/png");
  //   return dataURL.replace(/^data:image\/?[A-z]*;base64,/);
  // }
  
 
 console.log("compareProducts123",JSON.stringify(compareProducts));

 let img;
 var url = compareProducts[0].defaultImage.url.split('upload');
 function recurse() {
  console.log("abcd",compareProducts[0].defaultImage.url.split('upload'))
  alert("2")
  getBase64FromImageUrl({
    url: url
})
    .then((result) => {
      img=result
      alert("1")
        console.log("result",result)
    })
    .catch((error) => {
        console.log('error for base64', error);
    });
  // if(condition) {
  //     // stop calling itself
  //     //...
  // } else {
  //     recurse();
  // }
}

//recurse();

 const { jsPDF } = window.jspdf;
 const doc = new jsPDF({});

 doc.addImage(sbdLogo, 'png', 8, 6, 22, 8);
    doc.setLineWidth(0.001);
    doc.setDrawColor(169, 169, 169);
    doc.line(8,16,202,16);

    doc.setFontSize(12);
    doc.setFont("Montserrat", "bold");
    doc.text(8, 25, "Compare Products");
    
 var data = [
    {sku_1: compareProducts[0].defaultImage.url, 
    sku_2: compareProducts[1].defaultImage.url, 
    sku_3: compareProducts[2]!== undefined ? compareProducts[2].defaultImage.url : '', 
    sku_4: compareProducts[3]!== undefined ? compareProducts[3].defaultImage.url : ''
    },
    {sku_1: compareProducts[0].fields.Brand__c, 
    sku_2: compareProducts[1].fields.Brand__c, 
    sku_3: compareProducts[2]!== undefined ? compareProducts[2].fields.Brand__c : '', 
    sku_4: compareProducts[3]!== undefined ? compareProducts[3].fields.Brand__c : ''
    },
    {
      sku_1: compareProducts[0].fields.Name, 
      sku_2: compareProducts[1].fields.Name, 
      sku_3: compareProducts[2] !== undefined ? compareProducts[2].fields.Name : '', 
      sku_4: compareProducts[3] !== undefined ? compareProducts[3].fields.Name : ''
    },    
   {sku_1: compareProducts[0].sku, 
    sku_2: compareProducts[1].sku, 
    sku_3: compareProducts[2]!== undefined ? compareProducts[2].sku : '', 
    sku_4: compareProducts[3]!== undefined ? compareProducts[3].sku : ''
  }, 
  {sku_1: compareProducts[0].fields.LB2BStockAvailability__c, 
    sku_2: compareProducts[1].fields.LB2BStockAvailability__c, 
    sku_3: compareProducts[2]!== undefined ? compareProducts[2].fields.LB2BStockAvailability__c : '', 
    sku_4: compareProducts[3]!== undefined ? compareProducts[3].fields.LB2BStockAvailability__c : ''
  }
 
   
  ];
   
 var body = [...data.map(el => [el.sku_1, el.sku_2,el.sku_3, el.sku_4]), 
  //  [{content: `Total = ${total}`, colSpan: 4, 
  //    styles: { fillColor: [239, 154, 154] }
    //}]
  ]
   //const result = transpose(body);
   
 doc.autoTable({
  // head: [['Concept', 'Amount']],
   body: body,
   willDrawCell: function(cell, data)
   {   
       if(cell.row.index === 1){
            doc.setFontSize(8);
            doc.setFont("Montserrat", "normal");
            doc.setTextColor(211,211,211);
            
           // doc.setLineHeight(5.0);
           // doc.line(90, 30, 90, 50)
        }
        if(cell.row.index === 2){
            doc.setFontSize(8);
            doc.setFont("Montserrat", "bold");
           // console.log("aaa",cell);
          }
          if(cell.row.index === 3){
            doc.setFontSize(8);
            doc.setFont("Montserrat", "normal");
          }
          if(cell.row.index === 4){
            doc.setFontSize(8);
            doc.setFont("Montserrat", "normal");
          }
   },
   theme: 'grid',
   margin: {top: 30,left:45},
   tableWidth: 'auto',
 });

 doc.save("table.pdf");

//  let headers = createHeaders([
//     "image",
//     "sku",
//     "name",
// ]);

// function createHeaders(keys) {
//     var result = [];
//     for (var i = 0; i < keys.length; i += 1) {
//         result.push({
//             sku: keys[i],
//             name: keys[i],
//             prompt: keys[i],
//             width: 65,
//             align: "center",
//             padding: 0
//         });
//     }
//     return result;
// } 

//  let array = [];

//      for (let i = 0; i < compareProducts.length; i++) {
//         let data =
//         {
//             image:compareProducts[i].defaultImage.url,
//             sku: compareProducts[i].sku,
//             name:compareProducts[i].fields.Name,
//         };
//          array.push(data);
//      }
//      console.log("aaa",array);
 
//  const { jsPDF } = window.jspdf;
//  const doc = new jsPDF({});
    
// doc.table(30, 30, array,headers,{ autosize:true });

// const { jsPDF } = window.jspdf;
//   const doc = new jsPDF({});
//   var y = 10;
//   var x = 10;
// //var doc = new jsPDF('p', 'pt')

//  let array = [];
      //for (let i = 0; i < compareProducts.length; i++) {
      //  doc.text(10, y = y + 5, compareProducts[0].sku);
      //  const splitText = doc.splitTextToSize(compareProducts[0].fields.Name, 30);
      //  doc.text(10, y = y + 10,splitText);

     //  y = y+5
      //  x = x+5
      //  doc.text(x=x+10, y, compareProducts[i].sku);
      //  const splitText1 = doc.splitTextToSize(compareProducts[i].fields.Name, 30);
      //  doc.text(x=x+10, y, splitText1);
      //  doc.setLineWidth(0.1);
      //  doc.line(100, 20, 100, 60);
      // }
       
        
       // let obj =
       //  {
        //    // image:compareProducts[i].defaultImage.url,
        //     sku: compareProducts[i].sku,
        //    // skua: compareProducts[i+1].sku,
        //     name:compareProducts[i].fields.Name
       //  };
//         //let data = [{image:compareProducts[i].defaultImage.url}]
//        // console.log("abcd",Object.keys(data).map(function(k){return data[k]}).join(","));
         // array.push(obj);
     // }
//      console.log("aaa",array);
// Supply data via script
// var body = [
//           // ['SL.No', 'Product Name', 'Price', 'Model'],
//            [1, 'I-phone', 75000, '2021'],
//            [2, 'Realme', 25000, '2022'],
//            [3, 'Oneplus', 30000, '2021'],
//            ]
//var doc = new jsPDF('p','pt','a4');

// // let columns = [];
//  var body = array;
// // generate auto table with body
// var y = 10;
// doc.setLineWidth(2);
// doc.text(20, y = y + 30, "Compare Products");



// doc.autoTable({
//     body: body,
//     startY: 70,
//     theme: 'grid',
// margin: {horizontal: 10},
// // columnStyles: {
// //     0: {columnWidth: 30},
// //     1: {columnWidth: 20},
// //     2: {columnWidth: 100},
// //     3: {columnWidth: 100},
// // },
// styles: {
//     halign: 'right'
// },

//               })


   // doc.save('demo.pdf');
}