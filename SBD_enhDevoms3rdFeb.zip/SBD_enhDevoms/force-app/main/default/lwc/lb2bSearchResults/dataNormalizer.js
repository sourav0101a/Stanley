import { resolve } from 'c/lb2bCmsResourceResolver';
import { HtmlHelper } from 'c/lb2bUtil';

/**
 * Transform product search API response data into display-data.
 *
 * @param {ConnectApi.ProductSummaryPage} data
 */
export function transformData(data, indexVal) {
    const DEFAULT_PAGE_SIZE = 20;
    const { productsPage = {}, categories = {}, facets = [], locale = '' } = data || {};
    const {
        currencyIsoCode = '',
        total = 0,
        products = [],
        pageSize = DEFAULT_PAGE_SIZE
    } = productsPage;

    let indexValue = indexVal;

    // Fix issues with special characters
    let fixedCategories = categories;
    categories.category.name = HtmlHelper.parseHtml(categories.category.name);
    categories.children.map((x) => (x.category.name = HtmlHelper.parseHtml(x.category.name)));

    return {
        locale,
        total,
        pageSize,
        categoriesData: fixedCategories,
        facetsData: facets.map(
            ({
                nameOrId,
                attributeType,
                facetType: type,
                displayType,
                displayName,
                displayRank,
                values
            }) => {
                return {
                    // include a unique identifier to avoid the collision
                    // between Product2 and variant custom fields
                    id: `${nameOrId}:${attributeType}`,
                    nameOrId,
                    attributeType,
                    type,
                    displayType,
                    displayName,
                    displayRank,
                    values: values.map((v) => ({
                        displayName: HtmlHelper.replaceSpecialCharacters(v.displayName),
                        nameOrId: v.nameOrId,
                        productCount: v.productCount,
                        checked: false
                    }))
                };
            }
        ),
        /* Product list normalization */
        layoutData: products.map(
            ({ id, name,stock, defaultImage, fields, prices, purchaseQuantityRule }) => {
                defaultImage = defaultImage || {};
                const { unitPrice: negotiatedPrice, listPrice: listingPrice } = prices || {};

                const hasQuantityRule = !!purchaseQuantityRule;

                // console.log(fields);

                let newFields = {};
                for (let field in fields) {
                    newFields[field] = {};
                    newFields[field].value = HtmlHelper.replaceSpecialCharacters(
                        fields[field].value
                    );
                }

                return {
                    id,
                    name: HtmlHelper.replaceSpecialCharacters(name),
                    stock,
                    // fields: fields.forEach((field) => {
                    //     return { value: HtmlHelper.replaceSpecialCharacters(field.value) };
                    // }),
                    fields: newFields,
                    image: {
                        url: resolve(defaultImage.url),
                        title: defaultImage.title || '',
                        alternateText: defaultImage.alternateText || ''
                    },
                    prices: {
                        listingPrice,
                        negotiatedPrice,
                        currencyIsoCode
                    },
                    purchaseQuantityRule: hasQuantityRule
                        ? {
                              increment: parseInt(purchaseQuantityRule.increment),
                              minimum: parseInt(purchaseQuantityRule.minimum),
                              maximum: parseInt(purchaseQuantityRule.maximum)
                          }
                        : undefined,
                    index: indexValue = indexValue + 1,
                    isProduct: true
                };
            }
        )
    };
}