import { LightningElement, track, api, wire } from 'lwc';
import LB2BClose from '@salesforce/label/c.LB2BClose';
import LB2BSendToMultipleLocations from '@salesforce/label/c.LB2BSendToMultipleLocations';
import LB2BEditMultipleLocations from '@salesforce/label/c.LB2BEditMultipleLocations';
import LB2BCustomer from '@salesforce/label/c.LB2BCustomer';
import LB2BCustomerName from '@salesforce/label/c.LB2BCustomerName';
import LB2BCity from '@salesforce/label/c.LB2BCity';
import LB2BCancel from '@salesforce/label/c.LB2BCancel';
import LB2BSelectMultipleShipTo from '@salesforce/label/c.LB2BSelectMultipleShipTo';
import LB2BConfirm from '@salesforce/label/c.LB2BConfirm';
import { CurrentPageReference } from 'lightning/navigation';
import LB2BAddress from '@salesforce/label/c.LB2BAddress';
import { fireEvent, registerListener } from 'c/lb2bPubSub';
//import FORM_FACTOR from '@salesforce/client/formFactor';
// Salesforce fields
import USER_ID from '@salesforce/user/Id';

// Apex classes
import ID_FIELD from '@salesforce/schema/WebCart.Id';
import LB2BMultiple_ShipTo_Numbers__c from '@salesforce/schema/WebCart.LB2BMultiple_ShipTo_Numbers__c';
import LB2BMultiple_ShipTo_Ids__c from '@salesforce/schema/WebCart.LB2BMultiple_ShipTo_Ids__c';
import { updateRecord } from "lightning/uiRecordApi";

import getAccounts from '@salesforce/apex/LB2BSapAccountTableController.getAccounts';

export default class Lb2bShipToMultipleLocations extends LightningElement {

    /**
    * ID of the cart
    *
    * @type {string}
    */
    @api cartId;
    @track shipToList = [];
    @track sortBy;
    @track sortDirection;
    @api searchArray;
   
    multipleShipToIds = [];
    multipleShipToNums = [];
    selectedRows = [];
    selection = [];
    preSelectedRows =[];
    // if(FORM_FACTOR == 'large'){  
    //     console.log('Inside formfactor',FORM_FACTOR);
    //     this.customClass = 'disabled';
    // } 
    //customClass = FORM_FACTOR == 'Large' ? 'disabled' : 'disabled btn-primary';
    customClass = 'disabled';
    @track sapAccounts = [];
    @track sapNumber;
    userId = USER_ID;
    @track isModalOpen = false;
    @track buttonText;

    @wire(CurrentPageReference) pageRef;

    // multipleShipToColumns = [
    //     { label: LB2BCustomer, fieldName: 'sapNumber', sortable: "true" },
    //     { label: LB2BCustomerName, fieldName: 'accountName', sortable: "true" },
    //     { label: LB2BCity, fieldName: 'city', sortable: "true" },
    //     { label: LB2BAddress, fieldName: 'streetAddress', sortable: "true" },
    // ];

    multipleShipToColumns = [
        { label: LB2BCustomer, fieldName: 'custNumber', sortable: "true" },
        { label: LB2BCustomerName, fieldName: 'custName', sortable: "true" },
        { label: LB2BCity, fieldName: 'city', sortable: "true" },
        { label: LB2BAddress, fieldName: 'streetAddress', sortable: "true" },
    ];

    // @api
    // multipleShitpToLocations(value) {
    //     this.shipToList = value;
    //     this.searchArray = value;       
    // }

    @api
    multipleShitpToIds(values){
        let my_ids = [];        
        values.split(',').map((str) => {
            my_ids.push(str);
            this.preSelectedRows = my_ids;
        }).join(',');
        fireEvent(this.pageRef, 'multipleShipTo', this.preSelectedRows);    
        this.buttonText = this.preSelectedRows.length == 0 ? LB2BSendToMultipleLocations : LB2BEditMultipleLocations;
    }

    getSelectedRow(evt) {      
        this.selectedRows = JSON.parse(JSON.stringify(this.template.querySelector("lightning-datatable").getSelectedRows()));     
        let updatedItemsSet = new Set();  // List of selected items from the data table event.   
        let selectedItemsSet = new Set(this.selection); // List of selected items we maintain.   
        let loadedItemsSet = new Set();  // List of items currently loaded for the current view.
    
        this.shipToList.map((event) => {
            loadedItemsSet.add(event.sapAccountId);
        });
       
        if (evt.detail.selectedRows) {
            evt.detail.selectedRows.map((event) => {
                updatedItemsSet.add(event.sapAccountId);
            });
            updatedItemsSet.forEach((sapAccountId) => {  // Add any new items to the selection list
                if (!selectedItemsSet.has(sapAccountId)) {
                    selectedItemsSet.add(sapAccountId);
                }
            });        
        }       
        loadedItemsSet.forEach((sapAccountId) => {
            if (selectedItemsSet.has(sapAccountId) && !updatedItemsSet.has(sapAccountId)) {           
                selectedItemsSet.delete(sapAccountId);  // Remove any items that were unselected.
            }
        });

        this.selection = [...selectedItemsSet];        
    }

    openModal() {
        this.isModalOpen = true;
    }

    closeModal() {
        console.log('inside close event');
        this.shipToList = this.searchArray;
        this.isModalOpen = false;
    }

    label = {
        LB2BClose,
        LB2BSendToMultipleLocations,
        LB2BEditMultipleLocations,
        LB2BCustomer,
        LB2BCustomerName,
        LB2BCity,
        LB2BAddress,
        LB2BCancel,
        LB2BSelectMultipleShipTo,
        LB2BConfirm
    }

    connectedCallback() {
        this.buttonText = LB2BSendToMultipleLocations;
        registerListener('accountDependency', this.soldToChangeEvent, this);
        registerListener('closemodelevent', this.closeModal, this);
        //console.log('FORM_FACTOR',FORM_FACTOR);
        console.log('')
    }

    soldToChangeEvent(inpVal) {
        this.sapNumber = inpVal.sapNumber.split(' -');
        console.log("inp split sapnum",this.sapNumber[0])
        getAccounts({ userId: this.userId, sapNumber: this.sapNumber[0] })
        .then((result) => { 
            console.log(result);
            if (!result.hasError) {
                this.sapAccounts = result.sapAccounts;
            }
        })
        .catch((error) => {
            console.error(error);
        });

        this.buttonText = LB2BSendToMultipleLocations; 
        this.selection = [];
        this.selectedRows = [];
        this.preSelectedRows =[];
        this.multipleShipToIds =[];
        this.multipleShipToNums =[];
        this.customClass = inpVal.accountSelected == 'null' ? 'disabled ' : 'enabled';
        // if(FORM_FACTOR == 'Large'){  
        //     this.customClass = inpVal.accountSelected == 'null' ? 'disabled ' : 'enabled';
        //     alert('inside large',this.customClass)
        // } else {
        //     this.customClass = inpVal.accountSelected == 'null' ? 'disabled':'enabled';
        //     //this.customClass += ' btn-primary';
        // } 
               
    }

    updateMultipleShipTo() {
        let fields = {};
        fields[ID_FIELD.fieldApiName] = this.cartId;
        fields[LB2BMultiple_ShipTo_Numbers__c.fieldApiName] = this.multipleShipToNums.join(",");
        fields[LB2BMultiple_ShipTo_Ids__c.fieldApiName] = this.multipleShipToIds.join(",");
        
       const recordInput = {
            fields: fields
        };
        console.log('recordInput', recordInput);
        updateRecord(recordInput)
            .then((result) => {
                console.log('update record for multiple ship to IDs and numbers ', result);
            })
            .catch((error) => {
                console.log('error', error);
            });
    }

    confirmSelectedAccounts() {
        console.log("selected rows", this.selectedRows)
        this.multipleShipToIds = [];
        this.multipleShipToNums = [];
        this.selectedRows.forEach((info) => {
            this.multipleShipToIds.push(info.sapAccountId);
            this.multipleShipToNums.push(info.sapNumber);          
        });
        this.isModalOpen = false;
        this.preSelectedRows = this.multipleShipToIds;
        this.buttonText = this.selectedRows.length == 0 ? LB2BSendToMultipleLocations : LB2BEditMultipleLocations;
         if(this.selectedRows.length > 1) {
            this.updateMultipleShipTo();
        } 
        
        fireEvent(this.pageRef, 'multipleShipTo', this.selectedRows); 
        if (this.selectedRows.length == 1) {
            this.soldToChangeEvent();
        }
    }

    handleConfirm(event) {
        console.log(JSON.stringify(event.detail));
        this.selectedRows = event.detail;
        this.multipleShipToIds = [];
        this.multipleShipToNums = [];
        this.selectedRows.forEach((info) => {
            this.multipleShipToIds.push(info.id);
            this.multipleShipToNums.push(info.sapNumber);          
        });
        this.isModalOpen = false;
        this.preSelectedRows = this.multipleShipToIds;
        this.buttonText = this.selectedRows.length == 0 ? LB2BSendToMultipleLocations : LB2BEditMultipleLocations;
         if(this.selectedRows.length > 1) {
            this.updateMultipleShipTo();
        } 
        
        fireEvent(this.pageRef, 'multipleShipTo', this.selectedRows); 
        if (this.selectedRows.length == 1) {
            this.soldToChangeEvent();
        }
    }

    // doSorting(event) {
    //     this.sortBy = event.detail.fieldName;
    //     this.sortDirection = event.detail.sortDirection;
    //     this.sortData(this.sortBy, this.sortDirection);
    // }

    // sortData(fieldname, direction) {
    //     let parseData = JSON.parse(JSON.stringify(this.shipToList));
    //     // Return the value stored in the field
    //     let keyValue = (a) => {
    //         return a[fieldname];
    //     };
    //     // cheking reverse direction
    //     let isReverse = direction === 'asc' ? 1 : -1;
    //     // sorting data
    //     parseData.sort((x, y) => {
    //         x = keyValue(x) ? keyValue(x) : ''; // handling null values
    //         y = keyValue(y) ? keyValue(y) : '';
    //         // sorting values based on direction
    //         return isReverse * ((x > y) - (y > x));
    //     });
    //     this.shipToList = parseData;
    // }

    // handleSearch(event) {
    //     const searchKey = event.target.value.toLowerCase();
    //     if (searchKey) {
    //         this.shipToList = this.searchArray;

    //         if (this.searchArray) {
    //             let recs = [];
    //             for (let rec of this.searchArray) {
    //                 let valuesArray = Object.values(rec);

    //                 for (let val of valuesArray) {
    //                     let strVal = String(val);

    //                     if (strVal) {
    //                         if (strVal.toLowerCase().includes(searchKey)) {
    //                             recs.push(rec);
    //                             break;
    //                         }
    //                     }
    //                 }
    //             }
    //             this.shipToList = recs;
    //         }
    //     } else {
    //         this.shipToList = this.searchArray;
    //         this.template.querySelector('[data-id="datarow"]').selectedRows = this.selection;
    //     }
    // }

    get disableConfirm(){
        return !((this.selectedRows && this.selectedRows.length) || (this.selection && this.selection.length));
    }  
}