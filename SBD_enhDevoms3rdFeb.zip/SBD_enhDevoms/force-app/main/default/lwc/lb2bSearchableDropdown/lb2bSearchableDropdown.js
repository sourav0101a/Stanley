import { LightningElement, api } from 'lwc';

// Labels
import NoResults from '@salesforce/label/c.LB2BNoResults';
import TypeToSearch from '@salesforce/label/c.LB2BTypeToSearch';
import KeepTyping from '@salesforce/label/c.LB2BKeepTyping';

export default class Lb2bSearchableDropdown extends LightningElement {
    @api classes;
    @api placeholder;
    @api value;
    @api label;
    @api required;
    @api disabled;

    @api searchCountThreshold;

    isFocused = false;

    options = [];
    filteredOptions = [];

    timeoutId;
    loseFocusTimer;

    labels = {
        NoResults,
        TypeToSearch,
        KeepTyping
    };

    _displayMode;

    isInitialLoading = true;

    @api
    setOptions(value) {
        this.options = value;
        if (this.options.length <= parseInt(this.largeVolumeSize)) {
            this.filteredOptions = this.options;
        }

        // let _tempList = [];
        // for (let i = 0; i < 1000; i++) {
        //     _tempList.push({
        //         label: 'test ' + (i + 1),
        //         value: 'test ' + i,
        //         search: 'TEST ' + (i + 1)
        //     });
        // }
        // this.options = _tempList;

        if (this.options.length > this.searchCountThreshold) {
            this.filteredOptions = [];
            this.displayMode = 'TOO_MANY';
        } else if (this.options.length > 0) {
            this.filteredOptions = this.options;
            this.displayMode = 'NORMAL';
        } else {
            this.filteredOptions = [];
            this.displayMode = 'NO_RESULTS';
        }

        this.isInitialLoading = false;
    }

    @api
    setValue(value) {
        this.value = value;
    }

    get showTypingPrompt() {
        return this._displayMode === 'TOO_MANY' || this.isInitialLoading;
    }

    get showNoResultsError() {
        return this._displayMode === 'NO_RESULTS';
    }

    get showStillTooManyError() {
        return this._displayMode === 'KEEP_GOING';
    }

    get isNormal() {
        return !(this.showNoResultsError || this.showTypingPrompt || this.showStillTooManyError);
    }

    set displayMode(value) {
        this._displayMode = value;
    }

    handleOnChange(event) {
        clearTimeout(this.timeoutId);
        const filterText = event.detail.value.trim() || '';

        // Send out reset event to other selector
        if (filterText === '') {
            const selectEvent = new CustomEvent('selectoption', {
                detail: {
                    value: 'null|null'
                }
            });

            this.dispatchEvent(selectEvent);

            if (this.options.length > parseInt(this.searchCountThreshold)) {
                this.filteredOptions = [];
                this.displayMode = 'TOO_MANY';
            } else {
                this.filteredOptions = this.options;
            }

            return;
        }

        this.timeoutId = setTimeout(() => {
            const filterUpper = filterText.toUpperCase();
            const temp = this.options.filter((x) => x.search.includes(filterUpper));
            if (temp.length === 0) {
                this.displayMode = 'NO_RESULTS';
                this.filteredOptions = [];
            } else if (temp.length > this.searchCountThreshold) {
                this.displayMode = 'KEEP_GOING';
                this.filteredOptions = [];
            } else {
                this.filteredOptions = temp;
                this.displayMode = 'NORMAL';
            }
        }, 300);
    }

    handleSelectOption(event) {
        console.log("label event", event.currentTarget.dataset.label)
        this.selection = false;
        this.value = event.currentTarget.dataset.label;
        this.template.querySelector('lightning-input').value = this.value;
        const selectEvent = new CustomEvent('selectoption', {
            detail: {
                value: event.currentTarget.dataset.value,
                label: event.currentTarget.dataset.label,
                description: event.currentTarget.dataset.description
            }
        });

        this.dispatchEvent(selectEvent);

        this.isFocused = false;
    }

    get dropdownClasses() {
        let dropdownClasses =
            'slds-combobox slds-dropdown-trigger slds-dropdown-trigger_click combo';
        if (this.isFocused) {
            dropdownClasses += ' slds-is-open';
        }

        return dropdownClasses;
    }

    handleFocus(evt) {
        this.isFocused = true;
        window.setTimeout(() => window.addEventListener('click', this.handleBlur), 1000);
        evt.stopPropagation();
    }

    handleBlur = (evt) => {
        // console.log('blur start check');
        this.isFocused = false;
        window.removeEventListener('click', this.handleBlur);

        // console.log('blur end check');
    };
}