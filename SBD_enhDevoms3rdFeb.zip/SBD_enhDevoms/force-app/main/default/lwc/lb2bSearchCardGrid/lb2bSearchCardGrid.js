import { LightningElement, api, track, wire } from 'lwc';
import LOCALE from '@salesforce/i18n/locale';
import LB2BPriceInCart from '@salesforce/label/c.LB2BPriceInCart';
import LB2BLowStock from '@salesforce/label/c.LB2BLowStock';
import LB2BInStock from '@salesforce/label/c.LB2BInStock';
import LB2BOutOfStock from '@salesforce/label/c.LB2BOutOfStock';
import LB2BSku from '@salesforce/label/c.LB2BSku';
//  for check inventory availability 
import hasPermission from '@salesforce/customPermission/Internal_Sales_Rep';

/**
 * An organized display of a single product card.
 *
 * @fires SearchCard#calltoaction
 * @fires SearchCard#showdetail
 */
export default class lb2bSearchCardGrid extends LightningElement {
    label = {
        LB2BPriceInCart,
        LB2BSku,
        LB2BInStock,
        LB2BLowStock,
        LB2BOutOfStock
    };

    isGridView = true;
    checkItemQuantity = true;
    isInStock = true;
    isMexico = false;
    isCanada = false;
    isUsa = false;
    //variables for the incrementor
    minus = this.template.querySelector('minus');
    num = this.template.querySelector('num');

    @api displayMode;

    /**
     * An event fired when the user clicked on the action button. Here in this
     *  this is an add to cart button.
     *
     * Properties:
     *   - Bubbles: true
     *   - Composed: true
     *   - Cancelable: false
     *
     * @event SearchLayout#calltoaction
     * @type {CustomEvent}
     *
     * @property {String} detail.productId
     *   The unique identifier of the product.
     *
     * @export
     */

    /**
     * An event fired when the user indicates a desire to view the details of a product.
     *
     * Properties:
     *   - Bubbles: true
     *   - Composed: true
     *   - Cancelable: false
     *
     * @event SearchLayout#showdetail
     * @type {CustomEvent}
     *
     * @property {String} detail.productId
     *   The unique identifier of the product.
     *
     * @export
     */

    /**
     * A result set to be displayed in a layout.
     * @typedef {object} Product
     *
     * @property {string} id
     *  The id of the product
     *
     * @property {string} name
     *  Product name
     *
     * @property {Image} image
     *  Product Image Representation
     *
     * @property {object.<string, object>} fields
     *  Map containing field name as the key and it's field value inside an object.
     *
     * @property {Prices} prices
     *  Negotiated and listed price info
     */

    /**
     * A product image.
     * @typedef {object} Image
     *
     * @property {string} url
     *  The URL of an image.
     *
     * @property {string} title
     *  The title of the image.
     *
     * @property {string} alternativeText
     *  The alternative display text of the image.
     */

    /**
     * Prices associated to a product.
     *
     * @typedef {Object} Pricing
     *
     * @property {string} listingPrice
     *  Original price for a product.
     *
     * @property {string} negotiatedPrice
     *  Final price for a product after all discounts and/or entitlements are applied
     *  Format is a raw string without currency symbol
     *
     * @property {string} currencyIsoCode
     *  The ISO 4217 currency code for the product card prices listed
     */

    /**
     * Card layout configuration.
     * @typedef {object} CardConfig
     *
     * @property {Boolean} showImage
     *  Whether or not to show the product image.
     *
     * @property {string} resultsLayout
     *  Products layout. This is the same property available in it's parent
     *  {@see LayoutConfig}
     *
     * @property {Boolean} actionDisabled
     *  Whether or not to disable the action button.
     */

    /**
     * Gets or sets the display data for card.
     *
     * @type {Product}
     */
    @api
    displayData;

    /**
     * Gets the product image.
     *
     * @type {Image}
     * @readonly
     * @private
     */
    get image() {
        // console.log(this.displayData);
        return this.displayData.image || {};
    }

    /**
     * Gets the product price.
     *
     * @type {string}
     * @readonly
     * @private
     */
    get price() {
        const prices = this.displayData.prices;
        return prices.negotiatedPrice || prices.listingPrice;
    }

    /**
     * Whether or not the product has price.
     *
     * @type {Boolean}
     * @readonly
     * @private
     */
    get hasPrice() {
        return !!this.price;
    }

    get hasQuantityRule() {
        return !!this.displayData.purchaseQuantityRule;
    }
    
    get isInternalSalessRep(){
        return hasPermission;
     }

    connectedCallback(){
        this.getstockAvailabilityColor(this.displayData.stock);
    }

    getstockAvailabilityColor(data){
        if(data === LB2BInStock){
            this.stockAvailabilityColor = 'item-in-stock flex-right-or-left'
        }
        else if (data === LB2BOutOfStock){
            this.stockAvailabilityColor = 'item-out-stock flex-right-or-left'
        }
        else{
            this.stockAvailabilityColor = 'item-low-stock flex-right-or-left'
        }
    }

    /**
     * Emits a notification that the user wants to add the item to their cart.
     *
     * @fires SearchCard#calltoaction
     * @private
     */
    notifyAction() {
        this.dispatchEvent(
            new CustomEvent('calltoaction', {
                bubbles: true,
                composed: true,
                detail: {
                    productId: this.displayData.id,
                    productName: this.displayData.name
                }
            })
        );
    }

    /**
     * Emits a notification that the user indicates a desire to view the details of a product.
     *
     * @fires SearchCard#showdetail
     * @private
     */
    notifyShowDetail(evt) {
        evt.preventDefault();
       // console.log('notifyShowDetail >>> ', JSON.stringify(this.displayData.stock));
        this.dispatchEvent(
            new CustomEvent('showdetail', {
                bubbles: true,
                composed: true,
                detail: { 
                            productId: this.displayData.id,
                            //stock: JSON.stringify(this.displayData.stock)
                           // stock: 'test data'
                        }
            })
        );
    }
}