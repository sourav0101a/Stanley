import { LightningElement, api, track, wire } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import createParkCart from '@salesforce/apex/LB2BParkCartController.createParkCart';

import LB2BCancel from '@salesforce/label/c.LB2BCancel';
import LB2BAdd from '@salesforce/label/c.LB2BAdd';
import LB2BParkCart from '@salesforce/label/c.LB2BParkCart';
import LB2BParkCartName from '@salesforce/label/c.LB2BParkCartName';
import LB2BSuccess from '@salesforce/label/c.LB2BSuccess';
import LB2BCartParked from '@salesforce/label/c.LB2BCartParked';

export default class Lb2bParkCartPopUp extends LightningElement {

    label = {
        LB2BCancel,
        LB2BAdd,
        LB2BParkCart,
        LB2BParkCartName
    }

    @wire(CurrentPageReference) pageRef;

    _cartId;
    isLoading = false;
    createNewCart = false;
    addCustomClass = 'save-button disabled';
    @track cartName;


    @api
    get sendToParkCart() {
        return this._cartId;
    }

    set sendToParkCart(data) {
        this._cartId = data;
    }

    cancel() {
        const closeEvent = new CustomEvent("closemodal", {
            detail: { isNewCart: this.createNewCart }
        });
        this.dispatchEvent(closeEvent);
    }

    get disableAdd() {
        return !this.cartName;
    }

    addToParkCart() {

        this.isLoading = true;
        createParkCart({
            cartId: this._cartId,
            cartName: this.cartName

        }).then((result) => {
            this.createNewCart = true;
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 	LB2BSuccess,
                    message: LB2BCartParked,
                    variant: 'success',
                }),
            );
            this.cancel();
        })
            .catch((error) => {
                console.log('error while updating park cart name', error);
            });
    }

    handleCartname(event) {
        this.cartName = event.target.value;
        this.addCustomClass = event.target.value !== '' ? 'save-button enabled' : 'save-button disabled';
    }
}