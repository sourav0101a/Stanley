import { LightningElement,track, api } from 'lwc';
import getPlantNames from '@salesforce/apex/LB2BCheckAvailabilityController.getPlantNames';
import getLocationInfo from '@salesforce/apex/LB2BCheckAvailabilityController.getLocationInfo';
import getInventory from '@salesforce/apex/LB2BCheckAvailabilityController.getInventory';

export default class Lb2bCheckAvailability extends LightningElement {
    isModalOpen = false;
    plantNames;
    @track plantNameOptions = [];
    @api productSku;
    value;
    isLoading =  false;

    connectedCallback(){
        console.log('productSku------>  ', this.productSku);

    }

    handleCheckAvailability () {
        this.callGetPlantNames();
    }

    callGetPlantNames(){
        this.isLoading = true;
        getPlantNames()
        .then((result) => {
            console.log('Plant names result >>> ',result);
            for(let i = 0; i < result.length; i++){
                this.plantNameOptions.push({ label: result[i].Plant_Name__c, value:  result[i].Label });
            }

            if (this.plantNameOptions) {
                this.isLoading = false;
                this.isModalOpen = true;
                this.value = this.plantNameOptions.find(opt => opt.value === 'S081').label;
                console.log('value >>> ',this.value)
            }

            console.log('by default value:   ', this.plantNameOptions.find(opt => opt.value === 'S081').value)
            let byDefaultValue = this.plantNameOptions.find(opt => opt.value === 'S081').value; 
            this.callGetLocationInfo(byDefaultValue);
            
        })        
        .catch((error) => {
            console.log('error for plant names result: ', error);
        });
    }
    

    handlePlantNameChange(event){
        let plantName = event.target.options.find(opt => opt.value === event.detail.value).label;
        let plantLabel = event.detail.value;
        console.log('onchange >>> ', plantName, ' >> ', plantLabel )
        this.callGetLocationInfo(plantLabel);
    }

    //get locations 
    callGetLocationInfo(plant_label) {
        getLocationInfo({
            plantNumber: plant_label
        })
        .then((result) => {
            console.log('Plant location result >>> ', result);
            if (result.ExternalReference) {
                this.callGetInventory(result.ExternalReference);
            }
        })
        .catch((error) => {
            console.log('error for location result: ', error);
        });
    }
    
    //get inventory 
    callGetInventory(location_Identifier){
        let listOfSkus= [this.productSku];
        let listOflocation_Identifier= [location_Identifier];

        getInventory({
            sku: listOfSkus,
            locationIdentifier: listOflocation_Identifier
        })
        .then((result) => {
            console.log('result for getInventory: ', result);
        })
        .catch((error) => {
            console.log('error for getInventory: ', error);
        })
    }

    handleToggleOpenClick (event) {
        this.isModalOpen = false;
    }
}