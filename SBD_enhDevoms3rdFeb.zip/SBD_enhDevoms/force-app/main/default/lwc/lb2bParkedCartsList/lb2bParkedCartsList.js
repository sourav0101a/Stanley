import { LightningElement, api, track, wire } from 'lwc';
import getParkedCartList from '@salesforce/apex/LB2BParkCartController.getParkedCartList';
import getParkedCartItems from '@salesforce/apex/LB2BParkCartController.getParkedCartItems';
import getCurrentCart from '@salesforce/apex/LB2BParkCartController.getCurrentCartId';
import updateCartRecord from '@salesforce/apex/LB2BAccountSelectorController.updateCartAccounts';
import addToCart from '@salesforce/apex/LB2BCSVUploaderController.addToCart';
import { deleteRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import communityId from '@salesforce/community/Id';
import deleteCart from '@salesforce/apex/LB2BCartController.deleteCart';
import createCart from '@salesforce/apex/LB2BCartController.createCart';
import { updateRecord } from 'lightning/uiRecordApi';

import ID_FIELD from '@salesforce/schema/WebCart.Id';
import ORDERTYPEPICKLIST from '@salesforce/schema/WebCart.LB2BOrderType__c';
import COSTCENTER from '@salesforce/schema/WebCart.LB2BCostCenter__c';
import PO_NUMBER from '@salesforce/schema/WebCart.UI_Po_Number__c';
import STORE_NUMBER from '@salesforce/schema/WebCart.SAP_Store_Number__c';
import REQUESTED_DELIVERY_DATE from '@salesforce/schema/WebCart.Requested_Delivery_Date__c';
import SHIPPING_CONDITION from '@salesforce/schema/WebCart.Shipping_Condition__c';
import WORKFLOWID from '@salesforce/schema/WebCart.LB2BWorkFlowId__c';
import PCR_Code_1__c from '@salesforce/schema/WebCart.PCR_Code_1__c';
import PCR_Code_2__c from '@salesforce/schema/WebCart.PCR_Code_2__c';
import PCR_Code_3__c from '@salesforce/schema/WebCart.PCR_Code_3__c';
import PCR_Code_4__c from '@salesforce/schema/WebCart.PCR_Code_4__c';
import PCR_Code_5__c from '@salesforce/schema/WebCart.PCR_Code_5__c';
import PCR_Notes__c from '@salesforce/schema/WebCart.PCR_Notes__c';
import LB2BReasoncode__c  from '@salesforce/schema/WebCart.LB2BReasoncode__c';
import LB2BMultiple_ShipTo_Numbers__c  from '@salesforce/schema/WebCart.LB2BMultiple_ShipTo_Numbers__c';
import LB2BMultiple_ShipTo_Ids__c  from '@salesforce/schema/WebCart.LB2BMultiple_ShipTo_Ids__c';

//Cart Item Fields
import CIID_FIELD from '@salesforce/schema/CartItem.Id';
import CIWFLWID_FIELD from '@salesforce/schema/CartItem.LB2BItemWorkFlowId__c';

import LB2BParkedCarts from '@salesforce/label/c.LB2BParkedCarts';
import LB2BParkCartName from '@salesforce/label/c.LB2BParkCartName';
import LB2BSold_To from '@salesforce/label/c.LB2BSold_To';
import LB2BShip_To from '@salesforce/label/c.LB2BShip_To';
import LB2BParkedDate from '@salesforce/label/c.LB2BParkedDate';
import LB2BOrderType from '@salesforce/label/c.LB2BOrderType';
import LB2BItems from '@salesforce/label/c.LB2BItems';
import LB2BPONumber from '@salesforce/label/c.LB2BPONumber';
import LB2BStatus from '@salesforce/label/c.LB2BStatus';
import LB2BAction from '@salesforce/label/c.LB2BAction';
import LB2BSuccess from '@salesforce/label/c.LB2BSuccess';
import LB2BDeleteParkedCart from '@salesforce/label/c.LB2BDeleteParkedCart';
import LB2BNoDataFound from '@salesforce/label/c.LB2BNoDataFound';
import LB2BRemove from '@salesforce/label/c.LB2BRemove';
import LB2BSearch from '@salesforce/label/c.LB2BSearch';
import LB2BNoCartsFound from '@salesforce/label/c.LB2BNoCartsFound';

const COLUMNS = [
    { name: LB2BParkCartName, sortable: true, field: 'LB2BParkCartName__c', id: 1 },
    { name: LB2BSold_To, sortable: true, field: 'Sold_To_Number__c', id: 2 },
    { name: LB2BShip_To, sortable: true, field: 'Ship_To_Number__c', id: 3 },
    { name: LB2BParkedDate, sortable: true, field: 'Parked_Date__c', id: 4 },
    { name: LB2BOrderType, sortable: true, field: 'LB2BOrderType__c', id: 5 },
    { name: LB2BItems, sortable: true, field: 'LB2BItems__c', id: 6 },
    { name: LB2BPONumber, sortable: true, field: 'PO_Number__c', id: 7 },
    { name: LB2BStatus, sortable: true, field: 'LB2BStatus__c', id: 8 },
    { name: LB2BAction, id: 9 }
];

const CART_CHANGED_EVT = 'cartchanged';

export default class Lb2bParkedCartsList extends NavigationMixin(LightningElement) {


    label = {
        LB2BParkedCarts,
        LB2BNoDataFound,
        LB2BRemove,
        LB2BSearch,
        LB2BNoCartsFound
    }

    @api effectiveAccountId;
    sortDirection;
    @track initialRecords;
    isLoader = true;
    tableColumns = [];
    isSearch = false;
    @track fullDataList = [];
    @track filteredData = [];
    @track parkedCartId;
    @track parkedListId;
    @track parkedCartItems = [];
    @track currentCartId;

    @wire(CurrentPageReference)
    pageRef;

    constructor() {
        super();
        COLUMNS.forEach((_col) => {
            this.tableColumns.push({
                ..._col,
                sortDirection: 0,
                get isAscending() {
                    return this.sortDirection == 1;
                },
                get isDescending() {
                    return this.sortDirection == -1;
                },
                get isSorted() {
                    return this.sortDirection != 0;
                }
            });
        });
    }

    connectedCallback() {
        this.getParkedCarts();
        this.getCurrentCart();
    }

    getParkedCarts() {
        getParkedCartList({}).then((res) => {
            this.isLoader = false;
            this.initialRecords = res;
            this.fullDataList = [];
            this.filteredData = [];
            res.forEach((x) => {
            let x1 = {};
            console.log('this.filteredData >>>', JSON.parse(JSON.stringify(x.LB2BStatus__c)));
            if(x.LB2BStatus__c == 'Active'){
                 x1 = {
                    ...x,
                    search: `${x.LB2BParkCartName__c} ${x.Sold_To_Number__c} ${x.Ship_To_Number__c} ${x.Parked_Date__c} ${x.LB2BOrderType__c}`.toLowerCase(),
                    active: true
                };
            } else {
                 x1 = {
                    ...x,
                    search: `${x.LB2BParkCartName__c} ${x.Sold_To_Number__c} ${x.Ship_To_Number__c} ${x.Parked_Date__c} ${x.LB2BOrderType__c}`.toLowerCase(),
                    active: false
                };
            }
                this.fullDataList.push(x1);
                this.filteredData.push(x1);
                console.log('this.filteredData >>>', JSON.parse(JSON.stringify(this.filteredData)));
            });
            console.log("parked cart list-------->", res)
        })

    }

    getCurrentCart() {
        getCurrentCart({}).then((res) => {
            this.currentCartId = res[0].Id;
        })
    }

    deleteRow(evt) {
        this.isLoader = true;
        this.filteredData.splice(evt.target.dataset.index, 1);
        console.log('evt',evt);
        deleteRecord(evt.target.dataset.id)
            .then((result) => {
                this.isLoader = false;
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: LB2BSuccess,
                        message: LB2BDeleteParkedCart,
                        variant: 'success'
                    })
                );
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error deleting record',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            });

    }


    handleSearch(event) {
        this.isSearch = true;
        const searchKey = event.target.value.toLowerCase();
        if (searchKey) {
            this.filteredData = this.initialRecords;
            if (this.filteredData) {
                let searchRecords = [];

                for (let record of this.filteredData) {
                    let valuesArray = Object.values(record);

                    for (let val of valuesArray) {
                        let strVal = String(val);
                        if (strVal) {
                            if (strVal.toLowerCase().includes(searchKey)) {
                                searchRecords.push(record);
                                break;
                            }
                        }
                    }
                }
                this.filteredData = searchRecords;
            }
        } else {
            this.filteredData = this.initialRecords;
        }
    }

    handleNavigate(event) {
        this.isLoader = true;
        this.parkedCartId = event.target.dataset.value;
        this.parkedListId = event.target.dataset.id;
        this.customDelete();
    }

    customDelete(event) {
        deleteCart({
            communityId,
            effectiveAccountId: this.effectiveAccountId,
            activeCartOrId: this.currentCartId
        }).then(() => {
        }).then(() => {
            return createCart({
                communityId,
                effectiveAccountId: this.effectiveAccountId
            });
        }).then((result) => {
            localStorage.setItem('cartId', result.cartId);
            this.getParkedCartItems(this.parkedListId, result.cartId);
            this.updateCartDetails(result.cartId);
        })
            .catch((e) => {
                console.log(e);
            });
    }


    updateCartDetails(cartId) {

        let selectedCart;
        this.filteredData.forEach((c) => {
            if (c.Cart__c === this.parkedCartId) {
                selectedCart = c;
                console.log("selected cart", JSON.stringify(selectedCart))
            }
        })

        let fields = {};
        fields[ID_FIELD.fieldApiName] = cartId;
        
        selectedCart.LB2BCostCenter__c !== undefined ? fields[COSTCENTER.fieldApiName] = selectedCart.LB2BCostCenter__c: '';
        switch (selectedCart.LB2BOrderType__c) {
            case  'Point of Purchase' :  fields[ORDERTYPEPICKLIST.fieldApiName] = 'LB2BPointofPurchase';
            break;
            case  'Finished Goods' :  fields[ORDERTYPEPICKLIST.fieldApiName] = 'LB2BFinishedGoods';
            break;
            case  'Targeted Funds' :  fields[ORDERTYPEPICKLIST.fieldApiName] = 'LB2BTargetedFunds';
            break;
            case  'Export Affiliate' :  fields[ORDERTYPEPICKLIST.fieldApiName] = 'LB2BExportAffiliate';
            break;
            case  'Domestic Affiliates' :  fields[ORDERTYPEPICKLIST.fieldApiName] = 'LB2BDomesticAffiliates';
            break;
            case  'On Loan' :  fields[ORDERTYPEPICKLIST.fieldApiName] = 'LB2BOnLoan';
            break;
            case  'Free Goods' :  fields[ORDERTYPEPICKLIST.fieldApiName] = 'LB2BFreeGoods';
            break;
            
           }
        selectedCart.PO_Number__c !== undefined ? fields[PO_NUMBER.fieldApiName] = selectedCart.PO_Number__c:'';
        selectedCart.LB2BRequested_Delivery_Date__c !== undefined ? fields[REQUESTED_DELIVERY_DATE.fieldApiName] = selectedCart.LB2BRequested_Delivery_Date__c:'';
        selectedCart.LB2B_Store_Number__c !== undefined ? fields[STORE_NUMBER.fieldApiName] = selectedCart.LB2B_Store_Number__c: '';
        selectedCart.LB2BShipping_Condition__c !== undefined ? fields[SHIPPING_CONDITION.fieldApiName] = selectedCart.LB2BShipping_Condition__c: '';
        selectedCart.LB2BWorkFlowId__c !== undefined ? fields[WORKFLOWID.fieldApiName] = selectedCart.LB2BWorkFlowId__c:'';
        selectedCart.PCR_Code_1__c !== undefined ? fields[PCR_Code_1__c.fieldApiName] = selectedCart.PCR_Code_1__c:'';
        selectedCart.PCR_Code_2__c !== undefined ? fields[PCR_Code_2__c.fieldApiName] = selectedCart.PCR_Code_2__c: '';
        selectedCart.PCR_Code_3__c !== undefined ? fields[PCR_Code_3__c.fieldApiName] = selectedCart.PCR_Code_3__c: '';
        selectedCart.PCR_Code_4__c !== undefined ? fields[PCR_Code_4__c.fieldApiName] = selectedCart.PCR_Code_4__c: '';
        selectedCart.PCR_Code_5__c !== undefined ? fields[PCR_Code_5__c.fieldApiName] = selectedCart.PCR_Code_5__c: '';
        selectedCart.PCR_Notes__c !== undefined ? fields[PCR_Notes__c.fieldApiName] = selectedCart.PCR_Notes__c: '';
        selectedCart.LB2BReasonCode__c !== undefined ? fields[LB2BReasoncode__c.fieldApiName] = selectedCart.LB2BReasonCode__c: '';

        if(selectedCart.Ship_To_Number__c === 'Multiple'){
            fields[LB2BMultiple_ShipTo_Numbers__c.fieldApiName] = selectedCart.LB2BMultiple_ShipTo_Numbers__c;
            fields[LB2BMultiple_ShipTo_Ids__c.fieldApiName] = selectedCart.LB2BMultiple_ShipTo_Ids__c;
        }
       
        const recordInput = { fields: fields };
        console.log('recordInput >>>',recordInput)
        updateRecord(recordInput).then((result) => {
            console.log('result >>>',result);
        }).catch((error) => {
            console.log('error', error);
        });

        this.updateSoldToShipTo(
            cartId,selectedCart.Sold_To_Number__c,selectedCart.LB2BSoldTo__c,'SoldTo');
            if(selectedCart.Ship_To_Number__c !== 'Multiple'){
                this.updateSoldToShipTo(
                    cartId,selectedCart.Ship_To_Number__c,selectedCart.LB2BShipTo__c,'ShipTo');
            }
    }

    updateSoldToShipTo(cartId,sapNumber,Id,type){
        updateCartRecord({
            cartId: cartId,
            sapAccountNumber: sapNumber,
            sapAccountId: Id,
            accountType: type
        }).then((result) => {
                console.log('result updating the cart accounts', result);
            }).catch((error) => {
                console.log('Error updating the cart accounts', error);
            });    
    }

    handleCartUpdate() {
        this.dispatchEvent(
            new CustomEvent(CART_CHANGED_EVT, {
                bubbles: true,
                composed: true
            })
        );
    }

    navigateToCart(cartId) {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: cartId,
                objectApiName: 'WebCart',
                actionName: 'view'
            }
        });
    }
    parkedCartItemswf = [];
    getParkedCartItems(Id, cartId) {
        let obj = {}
        let wfIds = {}

        getParkedCartItems({
            Id: Id
        }).then(result => {
            console.log("cart items res", result)
            result.forEach((item) => {
                obj = { "sku": item.ProductSku__c, "quantity": item.Amount__c }
                if(item.LB2BItemWorkFlowId__c != undefined){
                    wfIds = {"sku": item.ProductSku__c, "workFlowId" : item.LB2BItemWorkFlowId__c}
                    this.parkedCartItemswf.push(wfIds);
                }
                
                this.parkedCartItems.push(obj);
            })
            this.addItemsToCart(cartId);
        })
    }

    addItemsToCart(newcartId) {
        var dataSet = JSON.stringify(this.parkedCartItems);
        addToCart({
            data: dataSet,
            communityId: communityId,
            effectiveAccountId: this.effectiveAccountId,
            isChecked: false
        })
            .then((result) => {
                if(this.parkedCartItemswf.length > 0){
                    for(let i=0; i < result.data.length; i++){
                    //    console.log('result.data[i].Id >>>',result.data[i].cartItemId,result.data[i].sku);
                    //    console.log('result.data sku >>>',this.parkedCartItemswf[i].workFlowId,this.parkedCartItemswf[i].sku);
                            
                        if(result.data[i].sku == this.parkedCartItemswf[i].sku){
                            let fields = {};
                           // console.log('fields',fields);
                            fields[CIID_FIELD.fieldApiName] = result.data[i].cartItemId;
                            fields[CIWFLWID_FIELD.fieldApiName] = this.parkedCartItemswf[i].workFlowId;
                          //  console.log('fields',fields);
                            const recordInput = { fields: fields };
                           // console.log('recordInput >>>',recordInput)
                            updateRecord(recordInput).then((result) => {
                                console.log('result1 >>>',result);
                            }).catch((error) => {
                                console.log('error', error);
                            });
                        }                     
                    }                
            }
                this.isLoader = false;
                this.navigateToCart(newcartId);
                this.handleCartUpdate();
            })
            .catch((error) => {
            });
    }

    handleSort(event) {
        const myColId = event.target.dataset.id;
        const currentCol = this.tableColumns.filter((_col) => {
            return _col.id == myColId;
        })[0];
        const currentColSortMode = currentCol.sortDirection;

        let newColSortMode;
        if (currentColSortMode == 0) {
            newColSortMode = 1;
        } else if (currentColSortMode == 1) {
            newColSortMode = -1;
        } else if (currentColSortMode == -1) {
            newColSortMode = 1;
        }
        this.tableColumns.forEach((_col) => {
            if (_col.id == myColId) {
                _col.sortDirection = newColSortMode;
            } else {
                _col.sortDirection = 0;
            }
        });

        this.filteredData.sort((a, b) => {
            const valA = new String(a[currentCol.field]).toUpperCase(); // ignore upper and lowercase
            const valB = new String(b[currentCol.field]).toUpperCase(); // ignore upper and lowercase
            if (valA < valB) {
                return -1 * newColSortMode;
            }
            if (valA > valB) {
                return 1 * newColSortMode;
            }

            // names must be equal
            return 0;
        });

        this.fullDataList.sort((a, b) => {
            const valA = new String(a[currentCol.field]).toUpperCase(); // ignore upper and lowercase
            const valB = new String(b[currentCol.field]).toUpperCase(); // ignore upper and lowercase
            if (valA < valB) {
                return -1 * newColSortMode;
            }
            if (valA > valB) {
                return 1 * newColSortMode;
            }

            // names must be equal
            return 0;
        });
    }

    get checkIfData() {
        if ((this.filteredData && this.filteredData.length > 0) || (this.isLoader) || (this.isSearch)) {
            return true;
        } else {
            return false;
        }
    }

    get checkIfSearchData() {
        if ((this.filteredData && this.filteredData.length > 0) || this.isLoader) {
            return true;
        } else {
            return false;
        }
    }

}