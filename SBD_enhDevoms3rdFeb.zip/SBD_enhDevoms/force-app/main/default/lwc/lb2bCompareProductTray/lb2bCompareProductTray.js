import { LightningElement, wire, track, api } from 'lwc';
import { registerListener, fireEvent } from 'c/lb2bPubSub';
import { CurrentPageReference, NavigationMixin } from 'lightning/navigation';

import LB2BLowStock from '@salesforce/label/c.LB2BLowStock';
import LB2BInStock from '@salesforce/label/c.LB2BInStock';
import LB2BOutOfStock from '@salesforce/label/c.LB2BOutOfStock';
import LB2BCompareProducts from '@salesforce/label/c.LB2BCompareProducts';
import LB2BRemove from '@salesforce/label/c.LB2BRemove';
import LB2BClearAll from '@salesforce/label/c.LB2BClearAll';
import LB2BCompareItems from '@salesforce/label/c.LB2BCompareItems';

export default class Lb2bCompareProductTray extends NavigationMixin(LightningElement) {

    @wire(CurrentPageReference)
    pageRef;

    labels = {
        LB2BInStock,
        LB2BLowStock,
        LB2BOutOfStock,
        LB2BCompareProducts,
        LB2BRemove,
        LB2BClearAll,
        LB2BCompareItems
    };
    
    greyButton = false;
    @track selectedProducts = [];
    @track stockAvailabilityColor;
   
    connectedCallback() {
        registerListener('compareProducts', this.handleCompareEvent, this);
     
        if (localStorage.getItem('selectedProducts') != null) {
            this.selectedProducts = JSON.parse(localStorage.getItem('selectedProducts'))
            this.getStockAvailabilityColor(this.selectedProducts)
        }
    }

    get CompareLabel() {
        return "COMPARE PRODUCTS (" + this.selectedProducts.length + "/4)";
    }

    get hasProducts() {
        return this.selectedProducts && this.selectedProducts.length;
    }

    get disableCompareItems() {
        if(this.selectedProducts.length === 1){
            this.greyButton = true;
        }
        return this.selectedProducts.length < 2;
        
    }

    selectedFinalProducts;
    handleCompareEvent(value) {
    
        if (value.checked) {
            console.log('Value Data ', JSON.stringify(value));
            this.selectedProducts.push(value);

            this.selectedFinalProducts = this.selectedProducts.map((user) => ({
                ...user,
                stockClass: user.data.stock === undefined || null ? '' : user.data.stock.replaceAll(' ', ''), // just for example
              }));

            this.selectedProducts = this.selectedFinalProducts;

             console.log('Selected Products', JSON.stringify(this.selectedProducts));
             console.log('Selected Products Length ', this.selectedProducts.length);
            
        } else {
            this.selectedProducts.forEach((prod, index) => {
                if (prod.data.id === value.data.id) {
                    this.selectedProducts.splice(index, 1);
                }
            })
        }
        if (this.selectedProducts.length === 4) {
            fireEvent(this.pageRef, 'maxLimit', this.selectedProducts);
        }
        this.greyButton = false;
       // this.getStockAvailabilityColor(this.selectedProducts);
        localStorage.setItem('selectedProducts', JSON.stringify(this.selectedProducts));
        this.disableCompareItems();
    }

    getStockAvailabilityColor(array) {
        console.log('Selected Products ',JSON.stringify(array));
         array.forEach(el => {
            if (el.data.stock === LB2BInStock) {
                this.stockAvailabilityColor = 'item-in-stock'
            } else if (el.data.stock === LB2BOutOfStock) {
                this.stockAvailabilityColor = 'item-out-stock'
            } else if (el.data.stock === LB2BLowStock) {
                this.stockAvailabilityColor = 'item-low-stock'
            }
     })
    }

    removeProduct(evt) {
        fireEvent(this.pageRef, 'handleCheckedProduct', evt.target.dataset.id);
        this.selectedProducts.splice(evt.target.dataset.index, 1);
        localStorage.setItem('selectedProducts', JSON.stringify(this.selectedProducts));
        this.disableCompareItems();
    }

    clearAllProducts() {
        this.selectedProducts.forEach((prod) => {
            fireEvent(this.pageRef, 'handleCheckedProduct', prod.data.id);
        })
        this.selectedProducts = [];
        localStorage.removeItem('selectedProducts');
    }

    compareAllProducts() {
        let url = (window.location.origin + window.location.pathname).split('/s/');
        let newUrl = url[0] + '/s/compare-products';

        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: newUrl
            }
        });
    }
}