import { LightningElement, track, api } from 'lwc';

const COLUMNS = [
    { name: 'Account Number', sortable: true, field: 'custNumber', id: 1 },
    { name: 'Customer Name', sortable: true, field: 'custName', id: 2 },
    { name: 'City', sortable: true, field: 'city', id: 3 },
    { name: 'Street Address', sortable: true, field: 'streetAddress', id: 4 },
    { name: 'Postal Code', sortable: true, field: 'postal', id: 5 }
];

export default class Lb2bSapAccountTable extends LightningElement {
    @track
    fullDataList = [];

    @track
    filteredData = [];

    message;
    searchmessage;

    tableColumns = [];
    searchTimer;

    soldToAccountId;

    @api
    set displayData(value) {
        this.fullDataList = [];
        this.filteredData = [];
        value.forEach((x) => {
            const x1 = {
                ...x,
                isChecked: false,
                search: `${x.custNumber} ${x.custNumber} ${x.streetAddress} ${x.city} ${x.postal}`.toLowerCase()
            };
            this.fullDataList.push(x1);
            this.filteredData.push(x1);
        });
    }

    get displayData() {
        return null;
    }

    constructor() {
        super();
        COLUMNS.forEach((_col) => {
            this.tableColumns.push({
                ..._col,
                sortDirection: 0,
                get isAscending() {
                    return this.sortDirection == 1;
                },
                get isDescending() {
                    return this.sortDirection == -1;
                },
                get isSorted() {
                    return this.sortDirection != 0;
                }
            });
        });
    }

    get countMessage() {
        const selectedCount = this.fullDataList.filter((_row) => _row.isChecked).length;
        if (selectedCount > 0) {
            return `You have ${selectedCount} row(s) selected.`;
        } else {
            return 'You do not have any rows selected.';
        }
    }

    get filteredSize() {
        return this.filteredData.length;
    }

    // Row checkbox event handler
    handleRowCheckboxClick(event) {
        const row = this.filteredData.find((_row) => _row.id == event.target.dataset.id);
        console.log(event.target.dataset.id);
        row.isChecked = event.target.checked;
        this.updateGlobalCheckbox();
    }

    // "Select all" checkbox event handler
    handleGlobalCheckboxClick(event) {
        const checkedState = event.target.checked;
        this.filteredData.forEach((_row) => (_row.isChecked = checkedState));
    }

    updateGlobalCheckbox() {
        const checkedCount = this.filteredData.filter((_row) => _row.isChecked).length;
        const globalCheckbox = this.template.querySelector('.global-checkbox');

        if (checkedCount == this.filteredData.length) {
            globalCheckbox.checked = true;
            globalCheckbox.indeterminate = false;
        } else if (checkedCount == 0) {
            globalCheckbox.checked = false;
            globalCheckbox.indeterminate = false;
        } else {
            globalCheckbox.checked = true;
            globalCheckbox.indeterminate = true;
        }
    }

    search(searchTerm) {
        console.log(searchTerm);
        if (!searchTerm || searchTerm.length < 3) {
            this.filteredData = this.fullDataList;
        } else {
            searchTerm = searchTerm.toLowerCase();
            this.filteredData = this.fullDataList.filter((_row) => {
                const val = _row.search.search(searchTerm);
                return val == -1 ? null : _row;
            });
        }

        this.updateGlobalCheckbox();
    }

    handleSearchTable(e) {
        console.log(e.target.value);
        if (this.searchTimer) {
            clearTimeout(this.searchTimer);
        }
        const searchTerm = e.target.value;
        this.searchTimer = setTimeout(() => {
            console.log('searching');
            this.search(searchTerm);
            if (!searchTerm) {
                this.searchmessage = '';
            } else if (searchTerm.length < 3) {
                this.searchmessage = 'Minimum 3 characters required to start search.';
            } else {
                this.searchmessage =
                    'Searched: "' + searchTerm + '". Found ' + this.filteredSize + ' rows.';
            }
        }, 250);
    }

    handleConfirmButton() {
        const checkedIds = this.fullDataList
            .filter((_row) => _row.isChecked)
            .map((x) => ({
                id: x.id,
                sapNumber: x.custNumber
            }));
        const evt = new CustomEvent('confirm', {
            detail: checkedIds
        });
        this.dispatchEvent(evt);
    }

    handleSort(event) {
        const myColId = event.target.dataset.id;
        const currentCol = this.tableColumns.filter((_col) => {
            return _col.id == myColId;
        })[0];
        const currentColSortMode = currentCol.sortDirection;

        let newColSortMode;
        if (currentColSortMode == 0) {
            newColSortMode = 1;
        } else if (currentColSortMode == 1) {
            newColSortMode = -1;
        } else if (currentColSortMode == -1) {
            newColSortMode = 1;
        }
        this.tableColumns.forEach((_col) => {
            if (_col.id == myColId) {
                _col.sortDirection = newColSortMode;
            } else {
                _col.sortDirection = 0;
            }
        });

        this.filteredData.sort((a, b) => {
            const valA = new String(a[currentCol.field]).toUpperCase(); // ignore upper and lowercase
            const valB = new String(b[currentCol.field]).toUpperCase(); // ignore upper and lowercase
            if (valA < valB) {
                return -1 * newColSortMode;
            }
            if (valA > valB) {
                return 1 * newColSortMode;
            }

            // names must be equal
            return 0;
        });

        this.fullDataList.sort((a, b) => {
            const valA = new String(a[currentCol.field]).toUpperCase(); // ignore upper and lowercase
            const valB = new String(b[currentCol.field]).toUpperCase(); // ignore upper and lowercase
            if (valA < valB) {
                return -1 * newColSortMode;
            }
            if (valA > valB) {
                return 1 * newColSortMode;
            }

            // names must be equal
            return 0;
        });
    }

    get checkIfData() {
        if (this.filteredData && this.filteredData.length > 0) {
            return true;
        } else {
            return false;
        }
    }
}