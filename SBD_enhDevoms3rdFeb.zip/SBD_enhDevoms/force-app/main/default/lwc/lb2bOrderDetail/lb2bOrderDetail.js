import { api, LightningElement, track, wire } from 'lwc';
// import getOrderStatus from "@salesforce/apex/LB2BCallEnosix.getOrderStatus";
import { NavigationMixin } from 'lightning/navigation';
import getOrderNo from '@salesforce/apex/LB2BCallEnosix.getOrderNo';
import getOrderDetail from '@salesforce/apex/LB2BCallEnosix.getOrderDetail';
import communityId from '@salesforce/community/Id';
import getWishlistSummaries from '@salesforce/apex/LB2BCartController.getWishlistSummaries';
import addItemsToWishlist from '@salesforce/apex/LB2BCartController.addItemsToWishlist';
import createWishlist from '@salesforce/apex/LB2BCartController.createWishlist';
import getSapAccountFlags from '@salesforce/apex/LB2BCartController.getSapAccountFlags';
import { CurrentPageReference } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import addToCart from '@salesforce/apex/LB2BCSVUploaderController.addToCart';
import LB2BSapOrder from '@salesforce/label/c.LB2BSapOrder';
import LB2BCreateAList from '@salesforce/label/c.LB2BCreateAList';
import LB2BExportToExcel from '@salesforce/label/c.LB2BExportToExcel';
import LB2BReorder from '@salesforce/label/c.LB2BReorder';
import LB2BOrderQty from '@salesforce/label/c.LB2BOrderQty';
import LB2BShipQty from '@salesforce/label/c.LB2BShipQty';
import LB2BEstShip from '@salesforce/label/c.LB2BEstShip';
import LB2BEstimatedDelivery from '@salesforce/label/c.LB2BEstimatedDelivery';
import LB2BTracking from '@salesforce/label/c.LB2BTracking';
import LB2BShipProNumber from '@salesforce/label/c.LB2BShipProNumber';
import LB2BCarrierName from '@salesforce/label/c.LB2BCarrierName';
import LB2BProductName from '@salesforce/label/c.LB2BProductName';
import LB2BExtPrice from '@salesforce/label/c.LB2BExtPrice';
import LB2BCarrier from '@salesforce/label/c.LB2BCarrier';
import LB2BShipDate from '@salesforce/label/c.LB2BShipDate';
import LB2BRejectedQty from '@salesforce/label/c.LB2BRejectedQty';
import LB2BRejectReason from '@salesforce/label/c.LB2BRejectReason';
import LB2BReorderInProgress from '@salesforce/label/c.LB2BReorderInProgress';
import LB2BAddingItemsToCart from '@salesforce/label/c.LB2BAddingItemsToCart';
import LB2BViewCart from '@salesforce/label/c.LB2BViewCart';
import LB2BContinueShopping from '@salesforce/label/c.LB2BContinueShopping';
import LB2BStatus from '@salesforce/label/c.LB2BStatus';
import LB2BAdd_All_List from '@salesforce/label/c.LB2BAdd_All_List';
import LB2BClose from '@salesforce/label/c.LB2BClose';
import LB2BCreateList from '@salesforce/label/c.LB2BCreateList';
import LB2BAddtoexistingList from '@salesforce/label/c.LB2BAddtoexistingList';
import LB2BCancel from '@salesforce/label/c.LB2BCancel';
import LB2BAdd from '@salesforce/label/c.LB2BAdd';
import LB2BSku from '@salesforce/label/c.LB2BSku';
import LB2BUnitPrice from '@salesforce/label/c.LB2BUnitPrice';
import LB2BShowModal from '@salesforce/label/c.LB2BShowModal';
import LB2BOrderDetailError from '@salesforce/label/c.LB2BOrderDetailError';
import LB2BReorderAllSkuNotexist from '@salesforce/label/c.LB2BReorderAllSkuNotexist';
import LB2BTrackingNumber from '@salesforce/label/c.LB2BTrackingNumber';
import LB2BError from '@salesforce/label/c.LB2BError';
import LB2BSuccess from '@salesforce/label/c.LB2BSuccess';
import LB2BListName from '@salesforce/label/c.LB2BListName';
import LB2BMyLists from '@salesforce/label/c.LB2BMyLists';
import LB2BButtonCancel from '@salesforce/label/c.LB2BButtonCancel';
import LB2BViewAll from '@salesforce/label/c.LB2BViewAll';
import LB2BNotAccess from '@salesforce/label/c.LB2BNotAccess';
import LB2BSoldToLabel from '@salesforce/label/c.LB2BSoldToLabel';
import LB2BShipToLabel from '@salesforce/label/c.LB2BShipToLabel';
import LB2BSales_Order_Number from '@salesforce/label/c.LB2BSales_Order_Number';
import LB2BShip_To from '@salesforce/label/c.LB2BShip_To';
import LB2BSold_To from '@salesforce/label/c.LB2BSold_To';
import LB2BFreight from '@salesforce/label/c.LB2BFreight';
import LB2BNetTotal from '@salesforce/label/c.LB2BNetTotal';
import LB2BPONumber from '@salesforce/label/c.LB2BPONumber';
import LB2BNetAmount from '@salesforce/label/c.LB2BNetAmount';
import LB2BOk from '@salesforce/label/c.LB2BOk';
import GlobalCSS from '@salesforce/resourceUrl/lb2b_global';
import { loadStyle } from 'lightning/platformResourceLoader';
import { toastUtil } from 'c/lb2bUtil';
import { registerListener } from 'c/lb2bPubSub';
import LOCALE from '@salesforce/i18n/locale';
import LB2BDeliveryNumber from '@salesforce/label/c.LB2BDeliveryNumber';
import {OrderTracking} from 'c/lb2bDataLayer';

export default class Lb2bOrderDetail extends NavigationMixin(LightningElement) {
    // @api recordId;
    @api cartIdFromLocalStorage;
    @api status;

    @api cartIdNew;

    label = {
        LB2BSapOrder,
        LB2BCreateAList,
        LB2BExportToExcel,
        LB2BReorder,
        LB2BOrderQty,
        LB2BShipQty,
        LB2BEstShip,
        LB2BEstimatedDelivery,
        LB2BTracking,
        LB2BProductName,
        LB2BExtPrice,
        LB2BCarrier,
        LB2BShipDate,
        LB2BRejectedQty,
        LB2BRejectReason,
        LB2BReorderInProgress,
        LB2BAddingItemsToCart,
        LB2BViewCart,
        LB2BContinueShopping,
        LB2BStatus,
        LB2BAdd_All_List,
        LB2BClose,
        LB2BCreateList,
        LB2BAddtoexistingList,
        LB2BCancel,
        LB2BAdd,
        LB2BSku,
        LB2BUnitPrice,
        LB2BOrderDetailError,
        LB2BShowModal,
        LB2BTrackingNumber,
        LB2BError,
        LB2BSuccess,
        LB2BListName,
        LB2BMyLists,
        LB2BButtonCancel,
        LB2BViewAll,
        LB2BDeliveryNumber,
        LB2BNotAccess,
        LB2BOk,
        LB2BSoldToLabel,
        LB2BShipToLabel,
        LB2BSales_Order_Number,
        LB2BPONumber,
        LB2BNetAmount,
        LB2BFreight,
        LB2BNetTotal,
		LB2BShip_To,
		LB2BSold_To,
        LB2BShipProNumber,
        LB2BCarrierName
    };

    columnHeader = [
        this.label.LB2BSku,
        this.label.LB2BOrderQty,
        this.label.LB2BShipQty,
        this.label.LB2BEstShip,
        this.label.LB2BProductName,
        this.label.LB2BUnitPrice,
        this.label.LB2BExtPrice,
        this.label.LB2BShipDate,
        this.label.LB2BRejectedQty,
        this.label.LB2BRejectReason,
        this.label.LB2BDeliveryNumber,
        this.label.LB2BTrackingNumber,
        this.label.LB2BShipProNumber,
        this.label.LB2BCarrierName
    ];
    /**
     * The effectiveAccountId provided by the cart detail flexipage.
     *
     * @type {string}
     */
    @api
    effectiveAccountId;

    /**
     * A wishlist summary.
     * @type {wishlist[]}
     */
    wishlist;

    /**
     * Name of the new wishlist
     * @type {String}
     */
    listname;

    /**
     * A NewWishlist Id
     * @type {String}
     */
    newWishlistId;

    /**
     * An Existing Wishlist Id
     * @type {String}
     */
    wishlistId;

    /**
     * An existing Wishlist Name
     * @type {String}
     */
    existingListName;

    // @track disabled= false;

    @track existingLists = [];
    @track openModal = false;

    data;
    uploadInfo = [];
    inputData = [];
    tableData = [];

    @track
    showTable = false;
    @track isUSA = false;
    @api soldToAccount;
    localebaseDate;
    localebaseDate1;
    @track customFormModal = false;

    /**
      * Representation of a  option.
      *
      * @typedef {Object} option
      *  *
      * @property {string} label
      * The label for the  option.
      *
      * @property {string} value
      * The value for the  option.
     
      */

    /**
     * A list of options useful for displaying options
     *
     * @type {option[]}
     */

    /**
     * Length of Wishlist Summaries
     * @type {Number}
     */
    currentPageReference = null;
    @api sapOrderNumber;
    existingListsLength;
    currCountry;
    isShowTrakingLink = true;

    connectedCallback() {
        // registerListener('usa',this.countryCheck,this);
        this.isLoader = true;
        this.cartIdFromLocalStorage = localStorage.getItem('cartId');
        console.log('record id ', this.cartIdFromLocalStorage);
        console.log('Effective Account Id:', this.effectiveAccountId);
        //this.getStatus();
        this.getLists();
        this.getSapDetails();
        if (LOCALE === 'es-MX') {
            this.isShowTrakingLink = false;
        }
    }
    /**
     * An object with the current PageReference.
     * This is needed for the pubsub library.
     *
     * @type {PageReference}
     */
    @wire(CurrentPageReference)
    pageRef;

    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        if (currentPageReference) {
            console.log('bbbb', currentPageReference.state.orderNumber);
            this.sapOrderNumber = currentPageReference.state.orderNumber;
        }
    }

    showAllSuccessMessage = true;
    @api orderStatus;
    @api _result;
    @api sapTotal = 0;
    @api sapFrieght;
    @track mapObj = [];
    @track item;
    @track listOfSKU = [];
    //'DCB609-2','D24000S'
    @track isLoader = false;

    getSapDetails() {
        getOrderDetail({
            SapNumber: this.sapOrderNumber
        })
            .then((result) => {
                console.log('GetOrderDetails:', result);
                this._result = result[0];
                this.currCountry = this._result.orderSoldTo.Country;
                this.isLoader = false;

                this.orderStatus = result[0].orderStatus.OverallStatusDescription;
                for (let i = 0; i < this._result.orderItems.length; i++) {
                    //Passing sku list to add products to wishlist
                    let skuList = this._result.orderItems[i].Material;
                    this.listOfSKU.push(skuList);

                    //TODO: Mapping sap data for Reorder
                    this.item = {};
                    this.item.sku = this._result.orderItems[i].Material;
                    this.item.qty = this._result.orderItems[i].OrderQuantity;
                    this.inputData.push(this.item);
                    this.uploadInfo.push({
                        sku: this._result.orderItems[i].Material,
                        quantity: this._result.orderItems[i].OrderQuantity
                    });

                    let ItemSchedules = [];
                    let normalUnitPrice =
                        this._result.orderItems[i].NetValueInDocumentCurrency /
                        this._result.orderItems[i].OrderQuantity;
                    let normalExtPrice = this._result.orderItems[i].NetValueInDocumentCurrency;
                    let USExtPrice;
                    let USUnitPrice;
                    let EstShipdate;
                    let Shipdate;
                    let EstDelivery;
                    let RejectedQuantity = 0;

                    /**
                     * @typedef ShipmentInfo
                     * @type {object}
                     * @property {Array<string>} trackingUrlArray
                     * @property {string} deliveryNumber
                     * @property {string} trackingNumber
                     * @property {string} shipproNumber
                     * @property {string} combinedTrackingUrl
                     */

                    /** @type {Array<ShipmentInfo>} */
                    let trackingInfo = [];

                    let ShipSapQty = 0;
                    let deliveryNumber;
                    let shipproNumber;
                    let carrierName;

                    this._result.orderItemUserDefined.forEach((element) => {
                        if (this._result.orderItems[i].SalesItem == element.SalesItem) {
                            if (element.FIELD === 'KZWI1') {
                                USExtPrice = element.VALUE;
                            } else if (element.FIELD === 'PRICE_UNIT') {
                                USUnitPrice =
                                    (USExtPrice / this._result.orderItems[i].OrderQuantity) *
                                    element.VALUE;
                            } else if (element.FIELD === 'LFDAT') {
                                EstShipdate = element.VALUE;
                            } else if (element.FIELD === 'WADAT_IST') {
                                Shipdate = element.VALUE;
                            } else if (element.FIELD === 'RFMNG') {
                                ShipSapQty = parseInt(element.VALUE);
                            } else if (element.FIELD === 'VBELN') {
                                deliveryNumber = element.VALUE;
                            } else if (element.FIELD === 'SHIPPRO') {
                                shipproNumber = element.VALUE;
                                console.log('shipproNumber:--', shipproNumber);
                            } else if (element.FIELD === 'CARRIER') {
                                carrierName = element.VALUE;
                                console.log('carrierName:--', carrierName);
                            }
                            else if (element.FIELD === 'ZZREJECTQT') {
                                RejectedQuantity = parseInt(element.VALUE);
                            } else if (
                                element.FIELD.includes('TRACKING_URL') ||
                                element.FIELD.includes('CTRACK')
                            ) {
                                // Separate the field name from the delivery number
                                let fieldNameSplit = element.FIELD.split('|').map((x) => x.trim());
                                deliveryNumber = fieldNameSplit[1];

                                // Add this delivery number to our trackingInfo array if it is not there yet
                                if (
                                    trackingInfo.length === 0 ||
                                    trackingInfo.filter((x) => x.deliveryNumber === deliveryNumber)
                                        .length === 0
                                ) {
                                    trackingInfo.push({
                                        deliveryNumber: deliveryNumber,
                                        trackingUrlArray: ['', '', '', '', '', '']
                                    });
                                }

                                let currentShipment = trackingInfo.filter(
                                    (x) => x.deliveryNumber === deliveryNumber
                                )[0];
                                if (fieldNameSplit[0].includes('TRACKING_URL')) {
                                    // Determine which URL part we have
                                    let partId = parseInt(fieldNameSplit[0].split('URL')[1]) - 1;
                                    currentShipment.trackingUrlArray[partId] = element.VALUE;
                                } else if (fieldNameSplit[0].includes('CTRACK')) {
                                    currentShipment.trackingNumber = element.VALUE;
                                } 
                            }
                        }
                    });

                    for (let shipment of trackingInfo) {
                        if (shipment.trackingUrlArray[0].length > 0) {
                            shipment.combinedTrackingUrl = '';
                            for (let urlPart of shipment.trackingUrlArray) {
                                if (urlPart) {
                                    shipment.combinedTrackingUrl += urlPart;
                                }
                            }
                            shipment.trackingUrlArray = undefined;
                        }
                    }

                    if (EstShipdate != null && EstShipdate != undefined) {
                        let EstYear =
                            EstShipdate == undefined || null ? '' : EstShipdate.substring(0, 4);
                        let EstMonth = EstShipdate.substring(4, 6);
                        let EstDate = EstShipdate.substring(6, 8);
                        let EstimatedDateFinal = new Date(Date.UTC(EstYear, EstMonth - 1, EstDate));
                        this.localebaseDate =
                            this.currCountry === 'US'
                                ? new Intl.DateTimeFormat('en-US').format(EstimatedDateFinal)
                                : this.currCountry === 'MX'
                                ? new Intl.DateTimeFormat('es-MX').format(EstimatedDateFinal)
                                : new Intl.DateTimeFormat('fr-CA').format(EstimatedDateFinal);
                    }
                    if (Shipdate != null && Shipdate != undefined) {
                        let EstYear1 = Shipdate.substring(0, 4);
                        let EstMonth1 = Shipdate.substring(4, 6);
                        let EstDate1 = Shipdate.substring(6, 8);
                        let ShipDateFinal = new Date(Date.UTC(EstYear1, EstMonth1 - 1, EstDate1));
                        this.localebaseDate1 =
                            this.currCountry === 'US'
                                ? new Intl.DateTimeFormat('en-US').format(ShipDateFinal)
                                : this.currCountry === 'MX'
                                ? new Intl.DateTimeFormat('es-MX').format(ShipDateFinal)
                                : new Intl.DateTimeFormat('fr-CA').format(ShipDateFinal);
                    }
                    let obj = {
                        id: i,
                        shipQty: ShipSapQty == undefined || null ? 0 : ShipSapQty,
                        Material: this._result.orderItems[i].Material,
                        OrderQuantity: this._result.orderItems[i].OrderQuantity,
                        EstimatedShipDate:
                            EstShipdate == undefined || null ? '' : this.localebaseDate,
                        //EstimatedShipDate: EstShipdate,
                        shipDate: Shipdate == undefined || null ? '' : this.localebaseDate1,
                        productName: this._result.orderItems[i].ItemDescription,
                        unitPrice: this.isUSA ? USUnitPrice.toFixed(2) : normalUnitPrice.toFixed(2),
                        extPrice: this.isUSA ? USExtPrice : normalExtPrice,
                        rejectQty: this._result.orderItems[i].ReasonForRejection,
                        rejectReason: this._result.orderStatus.RejectionStatusDescription,
                        ItemSchedules: ItemSchedules,
                        trackingInfo: trackingInfo,
                        rejectedQuantity: RejectedQuantity,
                        shipproNumber: shipproNumber,
                        carrierName: carrierName
                    };
                    for (let j = 0; j < this._result.orderItemsSchedule.length; j++) {
                        if (
                            this._result.orderItems[i].SalesItem ==
                            this._result.orderItemsSchedule[j].SalesItem
                        ) {
                            //&& (this._result.orderItemsSchedule[j].OrderQuantity !=0)
                            //  if(this._result.orderItemsSchedule[j].ScheduleLineNumber!="0001"){
                            // obj.EstimatedShipDate = this._result.orderItemsSchedule[j].ScheduleLineDate;
                            ItemSchedules.push(this._result.orderItemsSchedule[j]);
                            console.log('ItemSchedules', ItemSchedules);
                            obj.ItemSchedules = ItemSchedules;
                        }
                    }
                    this.mapObj.push(obj);
                }
                console.log('List of SKU:', JSON.stringify(this.listOfSKU));
            })
            .catch((error) => {
                this.isLoader = false;
                this.customFormModal = true;
                console.log('Error in getOrderDetail:', error);
            });
    }

    trackTrackingInfo(event){
        let trackingNumber = event.currentTarget.dataset.value;
        let trackingUrl = event.target.href;
        OrderTracking('order_tracking', trackingNumber, trackingUrl);
    }
    
    customDelete(event) {
        this.customFormModal = false;
        window.history.back();
    }

    exportToExcel() {
        console.log('inside method: ', this.mapObj);

        for (let i = 0; i < this._result.orderItems.length; i++) {
            this.sapTotal += this._result.orderItems[i].NetValueInDocumentCurrency;
        }
        this.sapTotal = parseFloat(this.sapTotal).toFixed(2);

        if (this._result.orderFrieght.length == 0) {
            this.sapFrieght = parseFloat(0).toFixed(2);
            console.log('iffreight' + this.sapFrieght);
        }
        // Prepare a html table

        let doc = '';
        doc += '<table>';
        doc += '<style>';
        doc += 'table, td {';
        doc += 'text-align : left;';
        doc += '}';
        doc += '</style>';
        doc += '<tr>';
        doc += '<td>' + '<b>';
        doc += this.label.LB2BSold_To + ':';
        doc += '</b>' + '</td>';
        doc += '<td>';
        doc += this._result.orderSoldTo.PartnerName + '<br>';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>' + '<b>';
        doc += this.label.LB2BShip_To + ':';
        doc += '</b>' + '</td>';
        doc += '<td>';
        doc += this._result.orderShipTo.PartnerName + '<br>';
        doc += '</td>';
        doc += '</tr>';
        doc += '<tr>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += this._result.orderSoldTo.City + '<br>';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += this._result.orderShipTo.City + '<br>';
        doc += '<td>';
        doc += '</tr>';
        doc += '<tr>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += this._result.orderSoldTo.PostalCode + '<br>';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += this._result.orderShipTo.PostalCode + '<br>';
        doc += '<td>';
        doc += '</tr>';
        doc += '<tr>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += this._result.orderSoldTo.Country + '<br>';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += this._result.orderShipTo.Country + '<br>';
        doc += '<td>';
        doc += '</tr>';
        doc += '<tr>';
        doc += '<td>' + '<b>';
        doc += this.label.LB2BSales_Order_Number + ':';
        doc += '</b>' + '</td>';
        doc += '<td>';
        doc += this.sapOrderNumber + '<br>';
        doc += '<td>';
        doc += '<td>' + '<b>';
        doc += this.label.LB2BPONumber + ':';
        doc += '</b>' + '</td>';
        doc += '<td>';
        doc += this._result.orderPONum.CustomerPurchaseOrderNumber + '<br>';
        doc += '</td>';
        doc += '<td>';
        doc += '</tr>';
        doc += '<tr>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>' + '<b>';
        doc += this.label.LB2BNetTotal + ':';
        doc += '</b>' + '</td>';
        doc += '<td>';
        doc += this.sapTotal + '<br>';
        doc += '</td>';
        doc += '</tr>';
        doc += '<tr>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>' + '<b>';
        doc += this.label.LB2BFreight + ':';
        doc += '</b>' + '</td>';
        doc += '<td>';
        doc += '&nbsp;' + this.sapFrieght + '</br>';
        doc += '</td>';
        doc += '</tr>';
        doc += '<tr>';
        doc += '';
        doc += '</tr>';
        doc += '</table>';
        doc += '<table>';
        // Add styles for the table
        doc += '<style>';
        doc += 'table, th, td {';
        doc += '    border: 1px solid black;';
        doc += '    border-collapse: collapse;';
        doc += '    text-align: center;';
        doc += '}';
        doc += '</style>';
        // Add all the Table Headers
        doc += '<tr>';
        this.columnHeader.forEach((element) => {
            doc += '<th>' + element + '</th>';
        });
        doc += '</tr>';
        // Add the data rows
        this.mapObj.forEach((record) => {
            if (record) {
                doc += '<tr>';
                doc += '<th>' + record.Material + '</th>';
                doc += '<th>' + record.OrderQuantity + '</th>';
                doc += '<th>' + record.shipQty + '</th>';
                doc += '<th>' + record.EstimatedShipDate + '</th>';
                doc += '<th>' + record.productName + '</th>';
                doc += '<th>' + record.unitPrice + '</th>';
                doc += '<th>' + record.extPrice + '</th>';
                doc += '<th>' + record.shipDate + '</th>';                
                
                if (record.rejectedQuantity !== null) {
                    doc += '<th>' + record.rejectedQuantity + '</th>';
                } else {
                    doc += '<th>' + '</th>';
                }
                if (record.rejectReason) {
                    doc += '<th>' + record.rejectReason + '</th>';
                } else {
                    doc += '<th>' + '</th>';
                }
                if (record.trackingInfo){                    
                        record.trackingInfo.forEach((data) => {                            
                            if (data.deliveryNumber) {
                                    doc += '<th>' + (data.deliveryNumber + String.fromCharCode(8203)).replace('â€‹','') +  '</th>';
                            } else {
                                    doc += '<th>' + '</th>';
                            }
                            if (data.trackingNumber){
                                    doc += '<th>' + data.trackingNumber + '</th>';
                             } else {
                                    doc += '<th>' + '</th>';
                             }
                             
                    });
                }
                if (record.shipproNumber !== null) {
                    doc += '<th>' + record.shipproNumber + '</th>';
                } else {
                    doc += '<th>' + '</th>';
                }
                doc += '<th>' + record.carrierName + '</th>';
                doc += '</tr>';
            } else {
                doc += '<th>' + '</th>';
            }
        });
        doc += '</table>';
        var element = 'data:application/vnd.ms-excel,' + encodeURIComponent(doc);
        let downloadElement = document.createElement('a');
        downloadElement.href = element;
        downloadElement.target = '_self';
        // use .csv as extension on below line if you want to export data as csv
        downloadElement.download = 'Order Detail List.xls';
        document.body.appendChild(downloadElement);
        downloadElement.click();
    }

    handleAccrdionTable(event) {
        let accordionBtns = this.template.querySelectorAll('.accordion');
        accordionBtns.forEach((item) => {
            item.addEventListener('click', () => {
                item.parentElement.parentElement.classList.contains('is-open')
                    ? item.parentElement.parentElement.classList.remove('is-open')
                    : item.parentElement.parentElement.classList.add('is-open');
            });
        });
    }

    handleViewAll(e) {
        let viewAllStatus = e.target.checked;
        let viewAllTable = this.template.querySelector('.order-table-container');
        viewAllStatus
            ? viewAllTable.classList.add('show-all-table')
            : viewAllTable.classList.remove('show-all-table');
    }

    renderedCallback() {
        this.handleAccrdionTable();
        loadStyle(this, GlobalCSS);
    }

    //Boolean tracked variable to indicate if modal is open or not default value is false as modal is closed when page is loaded
    @track isModalOpen = false;
    openModalForList() {
        // to open modal set isModalOpen track value as true
        this.isModalOpen = true;
    }
    closeModalForList() {
        // to close modal set isModalOpen track value as false
        this.isModalOpen = false;
    }

    /*Handle Radio button Change */
    @track createListValue = true;
    @track addToListValue = false;

    handleRadioChange(event) {
        let selectedOption = event.target.value;
        if (selectedOption == 'createList') {
            this.createListValue = true;
        } else {
            this.createListValue = false;
        }
        if (selectedOption == 'addToList') {
            this.addToListValue = true;
        } else {
            this.addToListValue = false;
        }
    }

    //Gets all the wishlist summaries if any
    @track showExistingLists = false;
    getLists() {
        getWishlistSummaries({
            communityId,
            effectiveAccountId: this.effectiveAccountId
        }).then((result) => {
            this.data = JSON.parse(JSON.stringify(result));

            let listOption = [];

            this.existingListsLength = result.summaries.length;

            for (let i = 0; i < this.existingListsLength; i++) {
                this.existingListName = result.summaries[i].name;

                listOption.push({
                    label: this.existingListName
                        .replace('&amp;', '&')
                        .replace('&lt;/p&gt;', '')
                        .replace('&amp;amp;', '&')
                        .replace('&amp;#39;', "'"),
                    value: this.existingListName
                });
            }
            this.existingLists = listOption;
            //console.log("ExlistOptions:" ,JSON.parse(JSON.stringify(this.existingLists)));

            if (this.existingLists != 0) {
                this.showExistingLists = true;
            }
        });
    }

    /*Handle Existing Lists Dropdown*/
    handleExistingLists(event) {
        this.value = event.detail.value;
    }

    get options() {
        return this.existingLists;
    }

    handleCreateList() {
        this.isModalOpen = false;

        if (this.createListValue == true) {
            this.listname = this.template.querySelector(`[data-id = "newlist"]`).value;

            createWishlist({
                communityId,
                effectiveAccountId: this.effectiveAccountId,
                listname: this.listname
            })
                .then((result) => {
                    this.wishlist = result.summary;
                    this.newWishlistId = result.summary.id;

                    addItemsToWishlist({
                        communityId,
                        effectiveAccountId: this.effectiveAccountId,
                        wishlistId: this.newWishlistId,
                        skuList: JSON.stringify(this.listOfSKU)
                    })
                        .then((result) => {
                            console.log('Add Items To List:', result);
                            this.dispatchEvent(
                                new ShowToastEvent({
                                    title: this.label.LB2BSuccess,
                                    message: 'Products Added to Wishlist',
                                    variant: 'success',
                                    mode: 'dismissable'
                                })
                            );
                        })
                        .catch((error) => {
                            let message = this.label.LB2BOrderDetailError;
                            console.log('Error Msg:', message);

                            this.dispatchEvent(
                                new ShowToastEvent({
                                    title: 'Error',
                                    message: message,
                                    variant: 'error',
                                    mode: 'dismissable'
                                })
                            );
                        });
                })
                .catch((error) => {
                    let message = error.body.message;
                    console.log('Error Msg:', message);

                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: this.label.LB2BError,
                            message: message,
                            variant: 'error',
                            mode: 'dismissable'
                        })
                    );
                });
        }

        if (this.addToListValue == true) {
            let lName = this.template.querySelector(`[data-id = "existinglist"]`).value;

            let id;
            for (let i = 0; i < this.existingListsLength; i++) {
                if (this.data.summaries[i].name == lName) {
                    id = this.data.summaries[i].id;
                }
            }
            this.wishlistId = id;
            console.log('WishlistId: ', this.wishlistId);

            addItemsToWishlist({
                communityId,
                effectiveAccountId: this.effectiveAccountId,
                wishlistId: this.wishlistId,
                skuList: JSON.stringify(this.listOfSKU)
            })
                .then((result) => {
                    console.log('Add Items To List:', result);
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Products Added to Wishlist',
                            variant: 'success',
                            mode: 'dismissable'
                        })
                    );
                })
                .catch((error) => {
                    let message = this.label.LB2BOrderDetailError;
                    console.log('Error Msg:', message);

                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: this.label.LB2BError,
                            message: message,
                            variant: 'error',
                            mode: 'dismissable'
                        })
                    );
                });
        }
    }

    addItemsToCart() {
        var dataSet = JSON.stringify(this.uploadInfo);
        this.isLoader = true;

        if (this.uploadInfo.length != 0) {
            addToCart({
                data: dataSet,
                communityId: communityId,
                effectiveAccountId: this.effectiveAccountId,
                isChecked: false
            })
                .then((result) => {
                    this.isLoader = false;
                    this.showAllSuccessMessage = true;
                    if (result.isSuccess) {
                        console.log('resultcart:', result.data);
                        if (this.showAllSuccessMessage) {
                            if (
                                result.data.every((element) => {
                                    return element.isSuccess === false;
                                })
                            ) {
                                this.showAllSuccessMessage = false;
                                const event = new ShowToastEvent({
                                    title: this.label.LB2BError,
                                    message: LB2BReorderAllSkuNotexist,
                                    variant: 'error',
                                    mode: 'dismissable'
                                });
                                this.dispatchEvent(event);
                                return;
                            } else {
                                result.data.forEach((element) => {
                                    if (!element.isSuccess) {
                                        this.showAllSuccessMessage = false;
                                        const event = new ShowToastEvent({
                                            title: this.label.LB2BError,
                                            message: LB2BOrderDetailError,
                                            variant: 'error',
                                            mode: 'dismissable'
                                        });
                                        this.dispatchEvent(event);
                                        return;
                                    }
                                });
                            }
                        }
                        result.data.forEach((element) => {
                            let item = {};
                            item.sku = element.sku;
                            item.qty = element.quantity;
                            item.notes = element.message;
                            item.notesColor = element.isSuccess ? '' : 'slds-text-color_error';
                            this.inputData.push(item);
                            this.cartIdNew = element.cartId != undefined ? element.cartId : '';
                        });
                        if (this.showAllSuccessMessage) {
                            this.openModal = true;
                        }

                        this.tableData = this.inputData;
                        if (this.tableData.length > 0) {
                            this.showTable = true;
                        }

                        this.dispatchEvent(
                            new CustomEvent('cartchanged', {
                                bubbles: true,
                                composed: true
                            })
                        );
                    } else {
                        toastUtil.toastError(this, { message: result.message });
                        this.dispatchEvent(
                            new ShowToastEvent({
                                title: this.label.LB2BError,
                                message: result.message,
                                variant: 'error',
                                mode: 'dismissable'
                            })
                        );
                    }
                })
                .catch((error) => {
                    this.isLoader = false;
                    let message = error && error.body && error.body.message;
                    toastUtil.toastError(this, { message: message });
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: this.label.LB2BError,
                            message: message,
                            variant: 'error',
                            mode: 'dismissable'
                        })
                    );
                });
        }
    }

    closeModal() {
        this.openModal = false;
    }

    backToCartPage() {
        var pathname = new URL(window.location.href).pathname.split('?orderNumber');
        this.navigateToWebPage(pathname[0]);
        //toastUtil.toastSuccess(this, { message: LB2BReorderSuccessMsg });
    }

    navigateToWebPage(url) {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url.replace('/sap-order-detail', '/cart/' + this.cartIdNew)
            }
        });
    }
}